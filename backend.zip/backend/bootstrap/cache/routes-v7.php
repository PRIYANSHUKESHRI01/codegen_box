<?php

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sanctum.csrf-cookie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iKz4rqWz6fRY4Vti',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zX672asVYqCkzZyb',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/contact-requests' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::102IEfXUG4fVJj2z',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/newsletter/subscribe' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FWyOGg6nAHQp669w',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/public/stats' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::igRRqcTuokO5JDmL',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/public/problems/sample' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2JrDlwnYqlmnj4YR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/password/forgot' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mGZb525Riv7LQx6K',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/password/otp/verify' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EPu64o4q52MyIvkk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/password/reset' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Y1whE5yShTT6h0uw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CvCt0z09dSCPyelq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MKmghROlczatO6TX',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RjBUcpWAos5InMjE',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::d38Y42Xc77n1Ni8I',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/phone/verify' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qBVNseCqk0i5vkgn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/avatar' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5PTtx9tuIaKByLRD',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dcpIBRSuLkfAnxoq',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/sessions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3tJeOlVpADTw5cUW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/student-profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mNlYXWZstRyaBGsP',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/resume' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dn3HEguVOi2MA2FA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::G9AcNWoO3RW9m91B',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ctkxrRTvB68nZLEm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/subscription' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZtAelQZtxaDxqeOm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::S75W5e7XFr96aZcr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/overview' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ppAKyA76K3kw9vBi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/colleges' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iSz3QNJNURflmKSn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::d8HrtcO7PuauLLV1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/students/import-template' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::T3nIxqqlw8q1hEAN',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::M2ADqLAqh9zC8gBp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QLnrO1q4p2CmCOfn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/companies' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YBOulSZR70VFnbPc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ecOljS3M9os3qpwc',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/placement-drives' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nImGMh6IxzT8t97V',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OVj3z7Tsrr0dKQHT',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/partner-colleges' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::igoemiMIaJDGX0VF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/contests' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QplvtZuCbeipOppW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zXTdpTrDzufT41oR',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/interviews' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CHUDMY7Xjanm5qyl',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hiZ1YAicDJ6J8yXN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/interview-question-bank' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uFlUrajrkxCFSCqn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2SuLYtz7jkII0E3i',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/interview-role-templates' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7XqJsr1LLFk94bXv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2HbPIHfmgy4O678E',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/interview-tracks' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JubkIKm2alnYqh47',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WYTe4JYmnKLwOOLr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/soft-skills' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rxUj2uvLAGprRGY7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HT2yvMrbqIE05mCh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/soft-skill-question-bank' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rOQJtvnNJUEsvkKV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nqhmsqpjAkgtuaPk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/soft-skill-question-bank/generate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Llz6H6o2CnBsLDXv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/talent-pool/colleges' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PmGZ7VS0fkpWfgz7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/talent-pool/candidates' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XIGCQM3pLMFpNGp5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/article-topics' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sknleJrPiYFwlJ1o',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Rtd1WNzmTgJeMytx',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/articles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IgxzK3XK1et1bvHm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xdOmUKyHjEJ5C6Jq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/problems' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WftgqyP2iSr5XULZ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2u2798B2AGst24hA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/customers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6qdRX0bNJm2uxDdC',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/superadmin/overview' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mUSXDea0vFKy3nMk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/superadmin/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pQP7qTXRS8IikFMu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TVrjeIRwWOCGvF7U',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/superadmin/marketing-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OZNCAYJwyC0ZyIbs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/superadmin/audit-logs' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jRIbjuONsWlaXcSP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/superadmin/judge-nodes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LmVuTWRtEX2lSUA1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/superadmin/feature-flags' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PdgTj01TEEcGuXiE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/marketing/leads' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wm4NTBCWJmLNJnBW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/marketing/contact-requests' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::smiYnJlBtZFYxocq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/drives/mapped' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BXhGAOck7c04ebRV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/drives/available' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RNWHLCBoF4RAI0xm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/drives/pending' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hLlwU5ZrdHgsh8MY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/drives' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BprpFw3DHK8PMFaJ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/companies/search' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zR8rMoQndkgnYf5P',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/students/import-template' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pHJYBXWPOmwCL5KF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/students/import' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SaCYXYSM5ofWwrEj',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/students/imports' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Sg8JXdYipqFFcDjb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/students/cohort' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CTc1Vw1vtIzI5Y6x',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/students' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HAQKXzCCLnn7NIrv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/students/bulk-notify' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1pnw7cPDTpkkoKyR',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/coordinators' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7XTLnzPE1zUIpDIe',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xI2lKbYVzwm4cWxE',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/soft-skills' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DDaYy9FDHpSlm3FW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mRINjcqxxPrtJj7I',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/soft-skill-question-bank' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AGcZXZwKlX9qwwzM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/soft-skill-question-bank/generate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Wjdn7zKqETdWoEVR',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/reports/data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RGQ7acc02DQKbbU1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/placement-target' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SlxNnxM32ggezJE1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/proctoring' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GeS5vqHOfuanApVY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/contests' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gTByhffMMfPY6SqG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fO6K6bCR5ehAfzgY',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/interviews' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5DYcuiTBnzcBhsE5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SazlB3IKYvFGSl9z',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/interview-role-templates' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pLrjlk3BvaQw1psG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aAvsVjNChujRs0wr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tpo/interview-tracks' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WNLqFGRJaBGOdMmr',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GwZLChTN8hmikP45',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company/colleges' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Q2lVzsSNP84JUlGr',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company/drives' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eAq1lZgVdzB64C7v',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IKRoVHwJPk0uHMMR',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company/candidates/import-template' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dGnBMSvKnTGV87um',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company/contests' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CBysIcb3obzeJ4s7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QNPs5yUsx2iTCmHx',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company/interviews' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4yj4BmRd3E7W9CyQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LHzVXPR1rTmrNNto',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company/interview-role-templates' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::urAC82dlsKQZAAKU',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YuHwoS1uyuBn4Iz2',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company/interview-tracks' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dv5OJHN5KXJyh5u0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mMOeVMlQfHTqVz3d',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company/proctoring' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mIaiyq5EtTEnhZSQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company/reports/data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2OQk0khaU0ADE3L1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company/talent-pool' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RZW3rl2JS9HSIr3y',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company/talent-pool/inquiries' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CrESZdH76PysiS7Y',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company/soft-skills' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KmkebXYFi7k9syrR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zBgmGqbOmZfCte3u',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company/soft-skill-question-bank' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aPFKelHmmr6f6nnm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company/soft-skill-question-bank/generate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rymeWqybLftHJzIV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/coordinator/students' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a6dXIh2La2124Uiu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/coordinator/students/bulk-notify' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::suzmtg89kZmciqv1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/coordinator/proctoring' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZS7TDJIC3ZrUJI1b',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/problems' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ICoLD0JhALWIJrsS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/interview-question-bank/browse' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xlvp57EtxkSBM0Sf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/interview-question-bank/generate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2UnZp1SNBC5NGUGa',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/drives' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uTBDmjz8NgnxPOhT',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/submissions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2jU7BGLKMmaHRYjV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/stats' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rR2U3cY7Qma03puX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/rating-history' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Gh02BSHX2W2aHivP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/interviews' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MzZjePfPtRZqrtio',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/soft-skills' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tNwNKhlxuwD337xK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/leaderboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fRVdHFbwA6FlXjcy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/contests' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5GMe5skC4mI4cE1r',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/interviews' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2NXrM7vYZKkGovWC',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/soft-skills' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mV2HCMGoqI2KRDjb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/interview-tracks' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3srXANubiUsJy5zQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/articles/topics' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mP39NmWNFJWK2S52',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/learning-centre/overview' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Sc9hQ7I8vv5nYHlO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/learning-centre/speaking/prompts' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::N1wVAX44vtnu3HDX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/learning-centre/listening/lessons' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6snT2doMteUpvS3w',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/learning-centre/vocabulary/generate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eVJFTmuvd0zrcyv4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/talent-pool' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pbwoav1PsfUEOrOI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/talent-pool/opt-in' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cNIiYFO77r9KCJbU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/talent-pool/opt-out' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::k5xtxjPVXrMy6J10',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/up' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nOJoTvdv2stdQapi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3W5oHQWkYRNulvx4',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/(?|m(?|e/(?|sessions/([^/]++)(*:41)|talent\\-pool/inquiries/([^/]++)/respond(*:87))|arketing/(?|leads/(?|([^/]++)(?|(*:127)|/(?|status(*:145)|notes(*:158)))|notify(*:174))|contact\\-requests/([^/]++)(?|(*:212)|/(?|status(*:230)|notes(*:243)))))|a(?|dmin/(?|c(?|o(?|lleges/([^/]++)/(?|tpos(*:298)|coordinators(?|(*:321))|s(?|ubscription(*:345)|eats(*:357)|tudents/import(?|(*:382)|s(?|(*:394)|/([^/]++)(*:411)))))|ordinators/([^/]++)(?|(*:445)|/toggle\\-block(*:467))|mpanies/(?|([^/]++)(?|(*:498)|/(?|prep\\-questions(?|(*:528))|recommended\\-problems(?|(*:561))|subscription(*:582)))|admins/([^/]++)/toggle\\-block(*:621))|ntests/([^/]++)(?|(*:648)|/(?|p(?|roblems(?|(*:674)|/([^/]++)(*:691))|articipants(?|(*:714)|/([^/]++)/submissions(*:743)))|colleges(*:761)|finalize(*:777))))|ustomers/([^/]++)(?|(*:808)|/notes(*:822)))|t(?|pos/([^/]++)/toggle\\-block(*:862)|alent\\-pool/candidates/([^/]++)/visibility(*:912))|users/([^/]++)/toggle\\-block(*:949)|s(?|tudents/([^/]++)/(?|report(*:987)|submissions/([^/]++)(*:1015)|contest\\-submissions/([^/]++)(*:1053))|oft\\-skill(?|s/([^/]++)(?|(*:1089)|/questions(?|(*:1111)|/(?|([^/]++)(*:1132)|auto\\-fill(*:1151))))|\\-question\\-bank/([^/]++)(*:1188)))|p(?|r(?|ep\\-questions/([^/]++)(*:1229)|oblems/([^/]++)(*:1253))|lacement\\-drives/([^/]++)(?|(*:1291)|/map(?|pings(*:1312)|\\-colleges(*:1331))))|recommended\\-problems/([^/]++)(*:1373)|interview(?|s/([^/]++)(?|(*:1407)|/(?|questions(?|(*:1432)|/([^/]++)(*:1450))|colleges(*:1468)|sessions(?|(*:1488)|/([^/]++)/(?|re(?|sponses(*:1522)|instate(*:1538))|finalize(*:1556)))|responses/([^/]++)/(?|audio(*:1594)|score(*:1608))))|\\-(?|question\\-bank/([^/]++)(*:1648)|role\\-templates/([^/]++)(*:1681)|tracks/([^/]++)(?|(*:1708)|/colleges(*:1726))))|article(?|\\-topics/([^/]++)(?|(*:1768))|s/([^/]++)(?|(*:1791))))|rticles/(?|topics/([^/]++)(*:1829)|([^/]++)(?|(*:1849)|/read(*:1863))))|s(?|u(?|peradmin/(?|users/([^/]++)/(?|detail(*:1919)|toggle\\-block(*:1941)|permissions(*:1961))|feature\\-flags/([^/]++)/toggle(*:2001))|bmissions/([^/]++)(*:2029))|oft\\-skills/(?|([^/]++)(?|(*:2065)|/start(*:2080))|sessions/([^/]++)(?|/(?|answer(*:2120)|submit(*:2135))|(*:2145))))|tpo/(?|drives/([^/]++)/(?|map(?|(*:2189)|ping(*:2202))|unmap(*:2217)|respond(*:2233)|applications(?|(*:2257)|/(?|bulk\\-register(*:2284)|([^/]++)/stage(*:2307))))|s(?|tudents/(?|imports/([^/]++)(*:2350)|([^/]++)/(?|report(*:2377)|submissions/([^/]++)(*:2406)|contest\\-submissions/([^/]++)(*:2444)))|oft\\-skills/([^/]++)(?|(*:2478)|/questions(?|(*:2500)|/(?|([^/]++)(*:2521)|auto\\-fill(*:2540)))))|co(?|ordinators/([^/]++)(?|(*:2580)|/toggle\\-block(*:2603))|ntests/([^/]++)(?|(*:2631)|/(?|p(?|roblems(?|(*:2658)|/([^/]++)(*:2676))|articipants(?|(*:2700)|/([^/]++)/submissions(*:2730)))|finalize(*:2749))))|proctoring/([^/]++)(?|(*:2783)|/reinstate(*:2802))|interview(?|s/([^/]++)(?|(*:2837)|/(?|questions(?|(*:2862)|/([^/]++)(*:2880))|sessions(?|(*:2901)|/([^/]++)/(?|re(?|sponses(*:2935)|instate(*:2951))|finalize(*:2969)))|responses/([^/]++)/(?|audio(*:3007)|score(*:3021))))|\\-(?|role\\-templates/([^/]++)(*:3062)|tracks/([^/]++)(?|(*:3089)))))|co(?|mpany/(?|drives/([^/]++)(?|(*:3134)|/(?|propose(*:3154)|mappings(*:3171)|candidates(?|(*:3193)|/(?|([^/]++)/stage(*:3220)|import(?|(*:3238)|s(?|(*:3251)|/([^/]++)(*:3269)))))))|contests/([^/]++)(?|(*:3304)|/(?|problems(?|(*:3328)|/([^/]++)(*:3346))|finalize(*:3364)|invite(?|(*:3382)|d(*:3392))|results(?|(*:3412)|/import(*:3428))))|interview(?|s/([^/]++)(?|(*:3465)|/(?|questions(?|(*:3490)|/([^/]++)(*:3508))|invite(?|(*:3527)|d(*:3537))|sessions/([^/]++)/(?|re(?|sponses(*:3580)|instate(*:3596))|finalize(*:3614))|responses/([^/]++)/(?|audio(*:3651)|score(*:3665))))|\\-(?|role\\-templates/([^/]++)(*:3706)|tracks/([^/]++)(?|(*:3733))))|proctoring/([^/]++)(?|(*:3767)|/reinstate(*:3786))|talent\\-pool/([^/]++)(?|(*:3820)|/(?|resume(*:3839)|inter(?|est(*:3859)|view(*:3872))|hire(*:3886)|notify(*:3901)))|soft\\-skills/([^/]++)(?|(*:3936)|/questions(?|(*:3958)|/(?|([^/]++)(*:3979)|auto\\-fill(*:3998)))))|ordinator/(?|students/([^/]++)/(?|toggle\\-block(*:4058)|report(*:4073)|submissions/([^/]++)(*:4102)|contest\\-submissions/([^/]++)(*:4140))|proctoring/([^/]++)(?|(*:4172)|/reinstate(*:4191)))|ntest(?|\\-submissions/([^/]++)(*:4232)|s/([^/]++)(?|(*:4254)|/(?|register(?|(*:4278))|leaderboard(*:4299)|problems/([^/]++)(?|(*:4328)|/(?|run(*:4344)|submit(*:4359)|proctoring/(?|start(*:4387)|violations(*:4406))))))))|drives/([^/]++)(*:4437)|problems/([^/]++)(?|(*:4466)|/(?|run(*:4482)|submit(*:4497)))|judge/([^/]++)(*:4522)|interview(?|s/([^/]++)(?|(*:4556)|/(?|start(*:4574)|answer(*:4589)|complete(*:4606)|res(?|ult(*:4624)|ponses/([^/]++)/audio(*:4654))|proctoring/(?|start(*:4683)|violations(*:4702))))|\\-tracks/([^/]++)(*:4731))|learning\\-centre/(?|speaking/prompts/([^/]++)(?|(*:4789)|/attempts(*:4807))|listening/lessons/([^/]++)(?|(*:4846)|/attempts(*:4864))|vocabulary/attempts/([^/]++)/submit(*:4909)))|/storage/(.*)(?|(*:4936)))/?$}sDu',
    ),
    3 => 
    array (
      41 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DsZ7RSTcdOPnUWNE',
          ),
          1 => 
          array (
            0 => 'tokenId',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      87 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::h4hiJorXmg4BzEBq',
          ),
          1 => 
          array (
            0 => 'inquiry',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      127 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::O21kqXnekrMuzqZZ',
          ),
          1 => 
          array (
            0 => 'lead',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      145 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::s66ybUxZjzmQKXT6',
          ),
          1 => 
          array (
            0 => 'lead',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      158 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DtEvaiyjHAM7qD4V',
          ),
          1 => 
          array (
            0 => 'lead',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      174 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f5qPeVt0FyJ3rPz9',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      212 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::d53ZFcpGDadmE4iu',
          ),
          1 => 
          array (
            0 => 'contactRequest',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      230 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BJAttMQiAAeZh9tx',
          ),
          1 => 
          array (
            0 => 'contactRequest',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      243 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WYVKhQPHoVtMO5vu',
          ),
          1 => 
          array (
            0 => 'contactRequest',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      298 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::verTJiuz1LNF97mC',
          ),
          1 => 
          array (
            0 => 'college',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      321 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3GRnCQyINSbaB4oE',
          ),
          1 => 
          array (
            0 => 'college',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H9UvqHy3PdzFBNd0',
          ),
          1 => 
          array (
            0 => 'college',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      345 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4Y4khpRndfw607iM',
          ),
          1 => 
          array (
            0 => 'college',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      357 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wGwXYII9l5ODFOgc',
          ),
          1 => 
          array (
            0 => 'college',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      382 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::19FSTmaHwcShr3TS',
          ),
          1 => 
          array (
            0 => 'college',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      394 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::p2BKCOIFMUg37QFf',
          ),
          1 => 
          array (
            0 => 'college',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      411 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZR8z2In4oZYeR0Xp',
          ),
          1 => 
          array (
            0 => 'college',
            1 => 'studentImport',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      445 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::in6egLD9SeZDEqBU',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      467 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jPEc6WxYHc8fqQWC',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      498 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bgxXQnNG3cDVk6Gn',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      528 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qBgPwlzQW4CiNaty',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4DaYUrUK9AyWVI5r',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      561 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jSOGps1miFNe5lpC',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lTUbjdMYWLTnw2or',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      582 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::S265K8j7crwaWvMC',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      621 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CX3yoOMZULdzjIDJ',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      648 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hof1ovkZUOBnavST',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      674 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::srecjOc2syLU9NlT',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3jdJZJ4ZHe1A8E68',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      691 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3KSRVlC0dMnpefIi',
          ),
          1 => 
          array (
            0 => 'contest',
            1 => 'contestProblem',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      714 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lrc1XAT4QFXvESnW',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      743 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::B74Lb2qqCSYvGJES',
          ),
          1 => 
          array (
            0 => 'contest',
            1 => 'student',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      761 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KRkMJgSLneO0k3kQ',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      777 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ksXNIgFfKWJUXpb7',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      808 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HpNv9PXZCrNoGJzM',
          ),
          1 => 
          array (
            0 => 'customer',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      822 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::l5xmrbxB0M1ez2se',
          ),
          1 => 
          array (
            0 => 'customer',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      862 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hqsgESUCFS2RxQ8P',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      912 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PrdnegyzrovP2ElN',
          ),
          1 => 
          array (
            0 => 'candidate',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      949 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HuUyiUPSv27wL4GB',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      987 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::22vRVjeKmOvHNi4U',
          ),
          1 => 
          array (
            0 => 'student',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1015 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::k1VobuPnHmgdNzjF',
          ),
          1 => 
          array (
            0 => 'student',
            1 => 'submission',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1053 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9p3DDpWg8mY9DrtN',
          ),
          1 => 
          array (
            0 => 'student',
            1 => 'contestSubmission',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1089 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3GBQ6Kcf2IrnX48m',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GpklFjIgs9WUsVtA',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1111 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kLCNji8bYtjbsFHY',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hVS10TKY3K4hzDWi',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1132 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Zipk5hTUfDFgpIjv',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
            1 => 'assessmentQuestion',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1151 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fYKV8xCqTNEOsABj',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1188 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FzSZbyMGFmmYxHpK',
          ),
          1 => 
          array (
            0 => 'softSkillQuestion',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1229 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OfhXmLRDi9iNDL2H',
          ),
          1 => 
          array (
            0 => 'prepQuestion',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1253 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NEESLSz8ZtOF2tgw',
          ),
          1 => 
          array (
            0 => 'problem',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1291 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6yK2GNguht0sKUo0',
          ),
          1 => 
          array (
            0 => 'placementDrive',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1312 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Oolf3jZ2neqQyNIz',
          ),
          1 => 
          array (
            0 => 'placementDrive',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1331 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SlDA91GwwISbn4B8',
          ),
          1 => 
          array (
            0 => 'placementDrive',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1373 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mO6PiVCuaH9bJCHJ',
          ),
          1 => 
          array (
            0 => 'recommendedProblem',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1407 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3O2HG23FSgf8OG80',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sypcee9BGIl434Fb',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1432 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KdYh8jHybIirAOz4',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bl1Q7zK2YVDZctsR',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1450 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dJ7YxbsiQ9tXz027',
          ),
          1 => 
          array (
            0 => 'interview',
            1 => 'interviewQuestion',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1468 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::57hVXRHSpmsnIM2e',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1488 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JpMjuml4MHP1J8S6',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1522 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ymIv83KaZ0iQZm1j',
          ),
          1 => 
          array (
            0 => 'interview',
            1 => 'interviewSession',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1538 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kdCTgXxTXxoF4Z8u',
          ),
          1 => 
          array (
            0 => 'interview',
            1 => 'interviewSession',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1556 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::M3011I5clY9FgZBe',
          ),
          1 => 
          array (
            0 => 'interview',
            1 => 'interviewSession',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1594 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rUSiJBJjJI0umR2W',
          ),
          1 => 
          array (
            0 => 'interview',
            1 => 'interviewResponse',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1608 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2983FyAp1uZLIogj',
          ),
          1 => 
          array (
            0 => 'interview',
            1 => 'interviewResponse',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1648 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3MxmiN3LFtf4vftw',
          ),
          1 => 
          array (
            0 => 'interviewQuestionBank',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1681 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3BjhjAKWTMeMzDf7',
          ),
          1 => 
          array (
            0 => 'interviewRoleTemplate',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1708 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Lo9veweOUmPDt4rm',
          ),
          1 => 
          array (
            0 => 'interviewTrack',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::M2MrZStPwdtwbYdJ',
          ),
          1 => 
          array (
            0 => 'interviewTrack',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1726 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8qKoqZajQ4Vdn6KW',
          ),
          1 => 
          array (
            0 => 'interviewTrack',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1768 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ivHLKhNtqI9icprM',
          ),
          1 => 
          array (
            0 => 'articleTopic',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3XyvWWLBVU8KjCzi',
          ),
          1 => 
          array (
            0 => 'articleTopic',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1791 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UoY2aW6SRJsZesSR',
          ),
          1 => 
          array (
            0 => 'article',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ORnGoeDTxWRS1SvQ',
          ),
          1 => 
          array (
            0 => 'article',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SPKeMmIo0B3CMGDM',
          ),
          1 => 
          array (
            0 => 'article',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1829 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fyQAccCDUxA3Wlrs',
          ),
          1 => 
          array (
            0 => 'articleTopic',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1849 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Bdu0ALkYFl4Nh7IK',
          ),
          1 => 
          array (
            0 => 'article',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1863 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fC83rdzDcVTEGQA5',
          ),
          1 => 
          array (
            0 => 'article',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1919 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::L7098BVBzxwIFCPU',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1941 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vmoaZJx2lZB0KtFs',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1961 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::q8q2nDJCae4HyKcw',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2001 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2DpnUKGNhF5hiNND',
          ),
          1 => 
          array (
            0 => 'flag',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2029 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4fIv9DP9e7CwDruW',
          ),
          1 => 
          array (
            0 => 'submission',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2065 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9v6oJijk19JjLBBb',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2080 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::48SI16CgzZxViv6b',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2120 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::J4YJM7Ug5FCnHWiM',
          ),
          1 => 
          array (
            0 => 'softSkillSession',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2135 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4p3T9A2NVAJ3y485',
          ),
          1 => 
          array (
            0 => 'softSkillSession',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2145 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vKaC6NrjvCCh0ZmF',
          ),
          1 => 
          array (
            0 => 'softSkillSession',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2189 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EaNL8Pe1S7frcahV',
          ),
          1 => 
          array (
            0 => 'placementDrive',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2202 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ktjbdlxzmsE9bZdJ',
          ),
          1 => 
          array (
            0 => 'placementDrive',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2217 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::b8ZqylLxpiMnaqRJ',
          ),
          1 => 
          array (
            0 => 'placementDrive',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2233 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uveAuBqvR344BwSu',
          ),
          1 => 
          array (
            0 => 'placementDrive',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2257 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lPr4mbeiwOlBYM1Z',
          ),
          1 => 
          array (
            0 => 'placementDrive',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2f6JRH6Gr2loxxzl',
          ),
          1 => 
          array (
            0 => 'placementDrive',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2284 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vDLCxSQVVtIv2oLb',
          ),
          1 => 
          array (
            0 => 'placementDrive',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2307 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qFEGsUb8d6cXYMCy',
          ),
          1 => 
          array (
            0 => 'placementDrive',
            1 => 'application',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2350 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::G9Tmu0jh36CPSzRn',
          ),
          1 => 
          array (
            0 => 'studentImport',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2377 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0huYIi2X5McnGPoO',
          ),
          1 => 
          array (
            0 => 'student',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2406 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::i61A9jdIEBEZobPR',
          ),
          1 => 
          array (
            0 => 'student',
            1 => 'submission',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2444 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VJ9E00lCBnHZOCq5',
          ),
          1 => 
          array (
            0 => 'student',
            1 => 'contestSubmission',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2478 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8udhIDRTmuu9LMo0',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EvFGhX30qIuUX1AI',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2500 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HXNS0HE0JOxdjjQA',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7UmHp0t1N3tWtBZW',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2521 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hxSeOAhzH2SytpaN',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
            1 => 'assessmentQuestion',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2540 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cwRUxdIu0S6P6r21',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2580 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vsrjyQ5zEbYZAseH',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2603 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MakyAbPBBnwKzZGR',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2631 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MJhgje3ap3GulsgY',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2658 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::D8mH1XFJh1SRpYjL',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0Nn3bWbKcbBEkwea',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2676 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tKANpahsHKifn1sw',
          ),
          1 => 
          array (
            0 => 'contest',
            1 => 'contestProblem',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2700 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fChF1kRKKDUH3FUe',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2730 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jIGvGxKtD1q1AFSZ',
          ),
          1 => 
          array (
            0 => 'contest',
            1 => 'student',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2749 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::m6lb5zO6k77ptQko',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2783 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3IlR2Iox4Oh4m7vm',
          ),
          1 => 
          array (
            0 => 'proctoringSession',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2802 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hu7mqkPe0OwlNtNA',
          ),
          1 => 
          array (
            0 => 'proctoringSession',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2837 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::idj5UkNETOI1fr5H',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DQoPEeCQDfbswlCV',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2862 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::65IhnaLr6E9WQCKH',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ieGi32Xm0U4Uqgwn',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2880 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::n5NGNwSkjPO1kmU4',
          ),
          1 => 
          array (
            0 => 'interview',
            1 => 'interviewQuestion',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2901 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yjX6aeoHm15OgXuI',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2935 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Nc2pydHjG5MVp1ml',
          ),
          1 => 
          array (
            0 => 'interview',
            1 => 'interviewSession',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2951 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EUCGkkjPaQ0n5F9C',
          ),
          1 => 
          array (
            0 => 'interview',
            1 => 'interviewSession',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2969 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZyfzCoUNc1SBHzXL',
          ),
          1 => 
          array (
            0 => 'interview',
            1 => 'interviewSession',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3007 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qtoGuXMw6yQVAxuT',
          ),
          1 => 
          array (
            0 => 'interview',
            1 => 'interviewResponse',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3021 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PxqhecKc2ab8OPft',
          ),
          1 => 
          array (
            0 => 'interview',
            1 => 'interviewResponse',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3062 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TdjBzGUWtGhca6n1',
          ),
          1 => 
          array (
            0 => 'interviewRoleTemplate',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3089 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kdD6FXpuRuejENhk',
          ),
          1 => 
          array (
            0 => 'interviewTrack',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::i1Y02g8OnQu6yJUB',
          ),
          1 => 
          array (
            0 => 'interviewTrack',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3134 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LPTFFFrnlU7DjaCZ',
          ),
          1 => 
          array (
            0 => 'placementDrive',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NjrRPWTtGiPiRfCc',
          ),
          1 => 
          array (
            0 => 'placementDrive',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3154 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mv55b6BPu7Yzf3WW',
          ),
          1 => 
          array (
            0 => 'placementDrive',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3171 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aVbFJN8fDrg8N3tH',
          ),
          1 => 
          array (
            0 => 'placementDrive',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3193 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bQzchsQzJOYYB12Q',
          ),
          1 => 
          array (
            0 => 'placementDrive',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1dLB0WTZXLzvQ0KZ',
          ),
          1 => 
          array (
            0 => 'placementDrive',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3220 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aueq3mvCNV5jWMHu',
          ),
          1 => 
          array (
            0 => 'placementDrive',
            1 => 'application',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3238 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sLWBmYSHRptLQADA',
          ),
          1 => 
          array (
            0 => 'placementDrive',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3251 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fu6KHjp10I2AQ7Ar',
          ),
          1 => 
          array (
            0 => 'placementDrive',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3269 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TnIsGRDv2260niC9',
          ),
          1 => 
          array (
            0 => 'placementDrive',
            1 => 'candidateImport',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3304 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UfJXGYiFsELMsWcI',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3328 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::j2jeBW4anrkGATC8',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AWbmHGOT3xZJbBQq',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3346 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2ccoR0KluB8gxUYR',
          ),
          1 => 
          array (
            0 => 'contest',
            1 => 'contestProblem',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3364 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZJ7zlk1SQkuiiAfD',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3382 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kzCGQd53u2Qv7mHN',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3392 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2UX5fiTUPP5qoNzb',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3412 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aprR91nq6HXKnTdG',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3428 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gtV1kCo6Y8CyPpOH',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3465 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IeD7RbT8RMB44avb',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RgILmeF5mSu5EYD6',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3490 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::n4vTnQOSBkMQCHhE',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::P5zdM30fZawtVCKh',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3508 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1fjA9MAytO1bxP4Y',
          ),
          1 => 
          array (
            0 => 'interview',
            1 => 'interviewQuestion',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3527 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wWar4rONTcFxADNE',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3537 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hbltgLU0d2hl18HS',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3580 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UXr0reyzpab920OI',
          ),
          1 => 
          array (
            0 => 'interview',
            1 => 'interviewSession',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3596 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jP4wpxQGMmlv3qfO',
          ),
          1 => 
          array (
            0 => 'interview',
            1 => 'interviewSession',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3614 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::J5ACanVR2RhWBNCB',
          ),
          1 => 
          array (
            0 => 'interview',
            1 => 'interviewSession',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3651 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NMvFKMf0hWNDm2mK',
          ),
          1 => 
          array (
            0 => 'interview',
            1 => 'interviewResponse',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3665 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Jqqe7Ns2aHKx07tt',
          ),
          1 => 
          array (
            0 => 'interview',
            1 => 'interviewResponse',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3706 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cki7U3ctY3zZcSSY',
          ),
          1 => 
          array (
            0 => 'interviewRoleTemplate',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3733 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::w2R9shcdjkhEU7OP',
          ),
          1 => 
          array (
            0 => 'interviewTrack',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zIxIGrQTjtSfy27Q',
          ),
          1 => 
          array (
            0 => 'interviewTrack',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3767 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PR0hr19ht90mEgJQ',
          ),
          1 => 
          array (
            0 => 'proctoringSession',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3786 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CBHxBQFBVWmqpCVk',
          ),
          1 => 
          array (
            0 => 'proctoringSession',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3820 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SvqV571XpFw59vcv',
          ),
          1 => 
          array (
            0 => 'candidate',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3839 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YHjrFVsjtive4Kus',
          ),
          1 => 
          array (
            0 => 'candidate',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3859 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yEzaddhtzZooDo7k',
          ),
          1 => 
          array (
            0 => 'candidate',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3872 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Cy8xZYFWjXKGwj8n',
          ),
          1 => 
          array (
            0 => 'candidate',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3886 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tgxA1ifDzBgSndyk',
          ),
          1 => 
          array (
            0 => 'candidate',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3901 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JLZTjGQBXfKgrvcV',
          ),
          1 => 
          array (
            0 => 'candidate',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3936 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pIFZ31jLvlySLmQp',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0dcGVB8awJ851x4K',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3958 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TXbnFQ1wOzBix2e9',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::k2oAumhnTiUzQbhj',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3979 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wRbP68A7y9fIBAc0',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
            1 => 'assessmentQuestion',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3998 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sBG570Og2Gctwluh',
          ),
          1 => 
          array (
            0 => 'softSkillAssessment',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4058 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2i0WnWIhUzSl83aw',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4073 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kKh8LlvoiQsPVwZa',
          ),
          1 => 
          array (
            0 => 'student',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4102 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ko78xdzmRFU1DHW5',
          ),
          1 => 
          array (
            0 => 'student',
            1 => 'submission',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4140 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::moEp30xlq5QMn7Rp',
          ),
          1 => 
          array (
            0 => 'student',
            1 => 'contestSubmission',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4172 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5LjEFrJuOybOXG4u',
          ),
          1 => 
          array (
            0 => 'proctoringSession',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4191 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::g65SgDvMROg16MUh',
          ),
          1 => 
          array (
            0 => 'proctoringSession',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4232 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3BxX5poqK9MDwQTo',
          ),
          1 => 
          array (
            0 => 'contestSubmission',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4254 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TsSVDwU3oMQ1v46T',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4278 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::abZkhYQEdLm0Ybzd',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xDa6K2S4FTVXFVt4',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4299 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QWRNL4zHYR3CqEQa',
          ),
          1 => 
          array (
            0 => 'contest',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4328 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lOSXomwBN43zRi4n',
          ),
          1 => 
          array (
            0 => 'contest',
            1 => 'contestProblem',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4344 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::q9GoF61chP754QtQ',
          ),
          1 => 
          array (
            0 => 'contest',
            1 => 'contestProblem',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4359 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sf3IHXKHqL1sMKmh',
          ),
          1 => 
          array (
            0 => 'contest',
            1 => 'contestProblem',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4387 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xsxRWb3pHrD8i1OU',
          ),
          1 => 
          array (
            0 => 'contest',
            1 => 'contestProblem',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4406 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KeSzhbKIovHy44LC',
          ),
          1 => 
          array (
            0 => 'contest',
            1 => 'contestProblem',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4437 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CNzu0Ef36owKvAWf',
          ),
          1 => 
          array (
            0 => 'placementDrive',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4466 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rSxbg3yjFIakEiTU',
          ),
          1 => 
          array (
            0 => 'problem',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4482 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wTZaLgjqZbizTvCb',
          ),
          1 => 
          array (
            0 => 'problem',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4497 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ra72F4sXQkL9XiMB',
          ),
          1 => 
          array (
            0 => 'problem',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4522 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hRquWrPyDmLtaWOr',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4556 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lQd9lVxgwBycd9YY',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4574 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HH9OPcWbmzdH44D6',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4589 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OHB5dp3HPFPdHBT8',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4606 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CsLj1YS0vZvcwS6R',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4624 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZPNzdY1DHutCwyPF',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4654 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a8vNlbktHkhwU94O',
          ),
          1 => 
          array (
            0 => 'interview',
            1 => 'interviewResponse',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4683 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CGXNa1NYatQqjQgA',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4702 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lQyKKWkvzAlysYCo',
          ),
          1 => 
          array (
            0 => 'interview',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4731 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IaFsvGL39ZCfqcsr',
          ),
          1 => 
          array (
            0 => 'interviewTrack',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4789 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::A4KLgCzisbT9zTdc',
          ),
          1 => 
          array (
            0 => 'speakingPrompt',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4807 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IUMELcQHbZQfQtfg',
          ),
          1 => 
          array (
            0 => 'speakingPrompt',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4846 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uizhX0LZl0eI42iY',
          ),
          1 => 
          array (
            0 => 'listeningLesson',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4864 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JFYifPUQd9zMR5hT',
          ),
          1 => 
          array (
            0 => 'listeningLesson',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4909 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZXRxFrGDkZIUSz7G',
          ),
          1 => 
          array (
            0 => 'vocabularyAttempt',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4936 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'storage.local',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'storage.local.upload',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'sanctum.csrf-cookie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'sanctum.csrf-cookie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iKz4rqWz6fRY4Vti' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AuthController@register',
        'controller' => 'App\\Http\\Controllers\\Api\\AuthController@register',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::iKz4rqWz6fRY4Vti',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zX672asVYqCkzZyb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:login',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\Api\\AuthController@login',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::zX672asVYqCkzZyb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::102IEfXUG4fVJj2z' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/contact-requests',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:contact-request',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ContactRequestController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\ContactRequestController@store',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::102IEfXUG4fVJj2z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FWyOGg6nAHQp669w' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/newsletter/subscribe',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:newsletter-subscribe',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\NewsletterController@subscribe',
        'controller' => 'App\\Http\\Controllers\\Api\\NewsletterController@subscribe',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::FWyOGg6nAHQp669w',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::igRRqcTuokO5JDmL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/public/stats',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PublicController@stats',
        'controller' => 'App\\Http\\Controllers\\Api\\PublicController@stats',
        'namespace' => NULL,
        'prefix' => 'api/public',
        'where' => 
        array (
        ),
        'as' => 'generated::igRRqcTuokO5JDmL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2JrDlwnYqlmnj4YR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/public/problems/sample',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PublicController@sampleProblems',
        'controller' => 'App\\Http\\Controllers\\Api\\PublicController@sampleProblems',
        'namespace' => NULL,
        'prefix' => 'api/public',
        'where' => 
        array (
        ),
        'as' => 'generated::2JrDlwnYqlmnj4YR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mGZb525Riv7LQx6K' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/password/forgot',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:password-reset-request',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PasswordResetController@forgot',
        'controller' => 'App\\Http\\Controllers\\Api\\PasswordResetController@forgot',
        'namespace' => NULL,
        'prefix' => 'api/password',
        'where' => 
        array (
        ),
        'as' => 'generated::mGZb525Riv7LQx6K',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EPu64o4q52MyIvkk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/password/otp/verify',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:password-reset-verify',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PasswordResetController@verifyOtp',
        'controller' => 'App\\Http\\Controllers\\Api\\PasswordResetController@verifyOtp',
        'namespace' => NULL,
        'prefix' => 'api/password',
        'where' => 
        array (
        ),
        'as' => 'generated::EPu64o4q52MyIvkk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Y1whE5yShTT6h0uw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:password-reset-verify',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PasswordResetController@reset',
        'controller' => 'App\\Http\\Controllers\\Api\\PasswordResetController@reset',
        'namespace' => NULL,
        'prefix' => 'api/password',
        'where' => 
        array (
        ),
        'as' => 'generated::Y1whE5yShTT6h0uw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CvCt0z09dSCPyelq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/me',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AuthController@me',
        'controller' => 'App\\Http\\Controllers\\Api\\AuthController@me',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::CvCt0z09dSCPyelq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MKmghROlczatO6TX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\Api\\AuthController@logout',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::MKmghROlczatO6TX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RjBUcpWAos5InMjE' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/me/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AuthController@updateProfile',
        'controller' => 'App\\Http\\Controllers\\Api\\AuthController@updateProfile',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::RjBUcpWAos5InMjE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::d38Y42Xc77n1Ni8I' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/me/password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AuthController@updatePassword',
        'controller' => 'App\\Http\\Controllers\\Api\\AuthController@updatePassword',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::d38Y42Xc77n1Ni8I',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qBVNseCqk0i5vkgn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/me/phone/verify',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'throttle:phone-verify',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PhoneVerificationController@verify',
        'controller' => 'App\\Http\\Controllers\\Api\\PhoneVerificationController@verify',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::qBVNseCqk0i5vkgn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5PTtx9tuIaKByLRD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/me/avatar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AuthController@updateAvatar',
        'controller' => 'App\\Http\\Controllers\\Api\\AuthController@updateAvatar',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::5PTtx9tuIaKByLRD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dcpIBRSuLkfAnxoq' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/me/avatar',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AuthController@deleteAvatar',
        'controller' => 'App\\Http\\Controllers\\Api\\AuthController@deleteAvatar',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::dcpIBRSuLkfAnxoq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3tJeOlVpADTw5cUW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/me/sessions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AuthController@sessions',
        'controller' => 'App\\Http\\Controllers\\Api\\AuthController@sessions',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::3tJeOlVpADTw5cUW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DsZ7RSTcdOPnUWNE' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/me/sessions/{tokenId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AuthController@revokeSession',
        'controller' => 'App\\Http\\Controllers\\Api\\AuthController@revokeSession',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::DsZ7RSTcdOPnUWNE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mNlYXWZstRyaBGsP' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/me/student-profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentProfileController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentProfileController@update',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::mNlYXWZstRyaBGsP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dn3HEguVOi2MA2FA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/me/resume',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentProfileController@uploadResume',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentProfileController@uploadResume',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::dn3HEguVOi2MA2FA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::G9AcNWoO3RW9m91B' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/me/resume',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentProfileController@deleteResume',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentProfileController@deleteResume',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::G9AcNWoO3RW9m91B',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ctkxrRTvB68nZLEm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/me/resume',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentProfileController@downloadOwnResume',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentProfileController@downloadOwnResume',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ctkxrRTvB68nZLEm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZtAelQZtxaDxqeOm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/me/subscription',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SubscriptionController@mine',
        'controller' => 'App\\Http\\Controllers\\Api\\SubscriptionController@mine',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ZtAelQZtxaDxqeOm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::S75W5e7XFr96aZcr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/me/subscription',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SubscriptionController@subscribe',
        'controller' => 'App\\Http\\Controllers\\Api\\SubscriptionController@subscribe',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::S75W5e7XFr96aZcr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ppAKyA76K3kw9vBi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/overview',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminController@overview',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminController@overview',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::ppAKyA76K3kw9vBi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iSz3QNJNURflmKSn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/colleges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:colleges',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminController@colleges',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminController@colleges',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::iSz3QNJNURflmKSn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::d8HrtcO7PuauLLV1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/colleges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:colleges',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminController@storeCollege',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminController@storeCollege',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::d8HrtcO7PuauLLV1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::verTJiuz1LNF97mC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/colleges/{college}/tpos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:colleges',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminController@collegeTpos',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminController@collegeTpos',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::verTJiuz1LNF97mC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hqsgESUCFS2RxQ8P' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/tpos/{user}/toggle-block',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:colleges',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminController@toggleTpoBlock',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminController@toggleTpoBlock',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::hqsgESUCFS2RxQ8P',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3GRnCQyINSbaB4oE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/colleges/{college}/coordinators',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:colleges',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminController@collegeCoordinators',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminController@collegeCoordinators',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::3GRnCQyINSbaB4oE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::H9UvqHy3PdzFBNd0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/colleges/{college}/coordinators',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:colleges',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminController@storeCoordinatorForCollege',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminController@storeCoordinatorForCollege',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::H9UvqHy3PdzFBNd0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::in6egLD9SeZDEqBU' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/admin/coordinators/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:colleges',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminController@updateCoordinatorSection',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminController@updateCoordinatorSection',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::in6egLD9SeZDEqBU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jPEc6WxYHc8fqQWC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/coordinators/{user}/toggle-block',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:colleges',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminController@toggleCoordinatorBlock',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminController@toggleCoordinatorBlock',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::jPEc6WxYHc8fqQWC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4Y4khpRndfw607iM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/colleges/{college}/subscription',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:colleges',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminController@assignCollegeSubscription',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminController@assignCollegeSubscription',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::4Y4khpRndfw607iM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wGwXYII9l5ODFOgc' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/admin/colleges/{college}/seats',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:colleges',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminController@adjustCollegeSeats',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminController@adjustCollegeSeats',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::wGwXYII9l5ODFOgc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::T3nIxqqlw8q1hEAN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/students/import-template',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:colleges',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentImportController@template',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentImportController@template',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::T3nIxqqlw8q1hEAN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::19FSTmaHwcShr3TS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/colleges/{college}/students/import',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:colleges',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentImportController@storeForCollege',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentImportController@storeForCollege',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::19FSTmaHwcShr3TS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::p2BKCOIFMUg37QFf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/colleges/{college}/students/imports',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:colleges',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentImportController@indexForCollege',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentImportController@indexForCollege',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::p2BKCOIFMUg37QFf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZR8z2In4oZYeR0Xp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/colleges/{college}/students/imports/{studentImport}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:colleges',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentImportController@showForCollege',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentImportController@showForCollege',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::ZR8z2In4oZYeR0Xp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::M2ADqLAqh9zC8gBp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:platform_users',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminController@users',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminController@users',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::M2ADqLAqh9zC8gBp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QLnrO1q4p2CmCOfn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:platform_users',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminController@storeUser',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminController@storeUser',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::QLnrO1q4p2CmCOfn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HuUyiUPSv27wL4GB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/users/{user}/toggle-block',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:platform_users',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminController@toggleUserBlock',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminController@toggleUserBlock',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::HuUyiUPSv27wL4GB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::22vRVjeKmOvHNi4U' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/students/{student}/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:platform_users',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminStudentReportController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminStudentReportController@show',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::22vRVjeKmOvHNi4U',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::k1VobuPnHmgdNzjF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/students/{student}/submissions/{submission}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:platform_users',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminStudentReportController@submission',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminStudentReportController@submission',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::k1VobuPnHmgdNzjF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9p3DDpWg8mY9DrtN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/students/{student}/contest-submissions/{contestSubmission}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:platform_users',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminStudentReportController@contestSubmission',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminStudentReportController@contestSubmission',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::9p3DDpWg8mY9DrtN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YBOulSZR70VFnbPc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/companies',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:placements',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::YBOulSZR70VFnbPc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ecOljS3M9os3qpwc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/companies',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:placements',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::ecOljS3M9os3qpwc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bgxXQnNG3cDVk6Gn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/companies/{company}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:placements',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::bgxXQnNG3cDVk6Gn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qBgPwlzQW4CiNaty' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/companies/{company}/prep-questions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:placements',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@prepQuestions',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@prepQuestions',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::qBgPwlzQW4CiNaty',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4DaYUrUK9AyWVI5r' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/companies/{company}/prep-questions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:placements',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@storePrepQuestion',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@storePrepQuestion',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::4DaYUrUK9AyWVI5r',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OfhXmLRDi9iNDL2H' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/prep-questions/{prepQuestion}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:placements',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@destroyPrepQuestion',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@destroyPrepQuestion',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::OfhXmLRDi9iNDL2H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jSOGps1miFNe5lpC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/companies/{company}/recommended-problems',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:placements',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@recommendedProblems',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@recommendedProblems',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::jSOGps1miFNe5lpC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lTUbjdMYWLTnw2or' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/companies/{company}/recommended-problems',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:placements',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@storeRecommendedProblem',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@storeRecommendedProblem',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::lTUbjdMYWLTnw2or',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mO6PiVCuaH9bJCHJ' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/recommended-problems/{recommendedProblem}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:placements',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@destroyRecommendedProblem',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@destroyRecommendedProblem',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::mO6PiVCuaH9bJCHJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::S265K8j7crwaWvMC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/companies/{company}/subscription',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:placements',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@assignSubscription',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@assignSubscription',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::S265K8j7crwaWvMC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CX3yoOMZULdzjIDJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/companies/admins/{user}/toggle-block',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:placements',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@toggleAdminBlock',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminCompanyController@toggleAdminBlock',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::CX3yoOMZULdzjIDJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nImGMh6IxzT8t97V' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/placement-drives',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:placements',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminPlacementDriveController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminPlacementDriveController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::nImGMh6IxzT8t97V',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OVj3z7Tsrr0dKQHT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/placement-drives',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:placements',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminPlacementDriveController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminPlacementDriveController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::OVj3z7Tsrr0dKQHT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6yK2GNguht0sKUo0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/placement-drives/{placementDrive}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:placements',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminPlacementDriveController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminPlacementDriveController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::6yK2GNguht0sKUo0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::igoemiMIaJDGX0VF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/partner-colleges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:placements',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminPlacementDriveController@partnerColleges',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminPlacementDriveController@partnerColleges',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::igoemiMIaJDGX0VF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Oolf3jZ2neqQyNIz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/placement-drives/{placementDrive}/mappings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:placements',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminPlacementDriveController@mappings',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminPlacementDriveController@mappings',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::Oolf3jZ2neqQyNIz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SlDA91GwwISbn4B8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/placement-drives/{placementDrive}/map-colleges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:placements',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminPlacementDriveController@mapColleges',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminPlacementDriveController@mapColleges',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::SlDA91GwwISbn4B8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QplvtZuCbeipOppW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/contests',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:contests',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminContestController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminContestController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::QplvtZuCbeipOppW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zXTdpTrDzufT41oR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/contests',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:contests',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminContestController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminContestController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::zXTdpTrDzufT41oR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hof1ovkZUOBnavST' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/contests/{contest}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:contests',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminContestController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminContestController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::hof1ovkZUOBnavST',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::srecjOc2syLU9NlT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/contests/{contest}/problems',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:contests',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminContestController@problems',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminContestController@problems',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::srecjOc2syLU9NlT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3jdJZJ4ZHe1A8E68' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/contests/{contest}/problems',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:contests',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminContestController@storeProblem',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminContestController@storeProblem',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::3jdJZJ4ZHe1A8E68',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3KSRVlC0dMnpefIi' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/contests/{contest}/problems/{contestProblem}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:contests',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminContestController@destroyProblem',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminContestController@destroyProblem',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::3KSRVlC0dMnpefIi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KRkMJgSLneO0k3kQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/contests/{contest}/colleges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:contests',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminContestController@updateColleges',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminContestController@updateColleges',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::KRkMJgSLneO0k3kQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ksXNIgFfKWJUXpb7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/contests/{contest}/finalize',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:contests',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminContestController@finalize',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminContestController@finalize',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::ksXNIgFfKWJUXpb7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lrc1XAT4QFXvESnW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/contests/{contest}/participants',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:contests',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminContestController@participants',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminContestController@participants',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::lrc1XAT4QFXvESnW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::B74Lb2qqCSYvGJES' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/contests/{contest}/participants/{student}/submissions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:contests',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminContestController@participantSubmissions',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminContestController@participantSubmissions',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::B74Lb2qqCSYvGJES',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CHUDMY7Xjanm5qyl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/interviews',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::CHUDMY7Xjanm5qyl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hiZ1YAicDJ6J8yXN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/interviews',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::hiZ1YAicDJ6J8yXN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3O2HG23FSgf8OG80' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/interviews/{interview}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::3O2HG23FSgf8OG80',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sypcee9BGIl434Fb' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/interviews/{interview}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::sypcee9BGIl434Fb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KdYh8jHybIirAOz4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/interviews/{interview}/questions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@questions',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@questions',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::KdYh8jHybIirAOz4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bl1Q7zK2YVDZctsR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/interviews/{interview}/questions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@storeQuestion',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@storeQuestion',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::bl1Q7zK2YVDZctsR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dJ7YxbsiQ9tXz027' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/interviews/{interview}/questions/{interviewQuestion}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@destroyQuestion',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@destroyQuestion',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::dJ7YxbsiQ9tXz027',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::57hVXRHSpmsnIM2e' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/interviews/{interview}/colleges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@updateColleges',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@updateColleges',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::57hVXRHSpmsnIM2e',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uFlUrajrkxCFSCqn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/interview-question-bank',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewQuestionBankController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewQuestionBankController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::uFlUrajrkxCFSCqn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2SuLYtz7jkII0E3i' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/interview-question-bank',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewQuestionBankController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewQuestionBankController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::2SuLYtz7jkII0E3i',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3MxmiN3LFtf4vftw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/interview-question-bank/{interviewQuestionBank}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewQuestionBankController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewQuestionBankController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::3MxmiN3LFtf4vftw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JpMjuml4MHP1J8S6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/interviews/{interview}/sessions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@sessions',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@sessions',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::JpMjuml4MHP1J8S6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ymIv83KaZ0iQZm1j' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/interviews/{interview}/sessions/{interviewSession}/responses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@responses',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@responses',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::ymIv83KaZ0iQZm1j',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rUSiJBJjJI0umR2W' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/interviews/{interview}/responses/{interviewResponse}/audio',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@responseAudio',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@responseAudio',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::rUSiJBJjJI0umR2W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kdCTgXxTXxoF4Z8u' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/interviews/{interview}/sessions/{interviewSession}/reinstate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@reinstateProctoring',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@reinstateProctoring',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::kdCTgXxTXxoF4Z8u',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2983FyAp1uZLIogj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/interviews/{interview}/responses/{interviewResponse}/score',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@scoreResponse',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@scoreResponse',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::2983FyAp1uZLIogj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::M3011I5clY9FgZBe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/interviews/{interview}/sessions/{interviewSession}/finalize',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@finalizeSession',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewController@finalizeSession',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::M3011I5clY9FgZBe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7XqJsr1LLFk94bXv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/interview-role-templates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewRoleTemplateController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewRoleTemplateController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::7XqJsr1LLFk94bXv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2HbPIHfmgy4O678E' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/interview-role-templates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewRoleTemplateController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewRoleTemplateController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::2HbPIHfmgy4O678E',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3BjhjAKWTMeMzDf7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/interview-role-templates/{interviewRoleTemplate}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewRoleTemplateController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewRoleTemplateController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::3BjhjAKWTMeMzDf7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JubkIKm2alnYqh47' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/interview-tracks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewTrackController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewTrackController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::JubkIKm2alnYqh47',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WYTe4JYmnKLwOOLr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/interview-tracks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewTrackController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewTrackController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::WYTe4JYmnKLwOOLr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Lo9veweOUmPDt4rm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/interview-tracks/{interviewTrack}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewTrackController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewTrackController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::Lo9veweOUmPDt4rm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::M2MrZStPwdtwbYdJ' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/interview-tracks/{interviewTrack}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewTrackController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewTrackController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::M2MrZStPwdtwbYdJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8qKoqZajQ4Vdn6KW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/interview-tracks/{interviewTrack}/colleges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:interviews',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminInterviewTrackController@updateColleges',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminInterviewTrackController@updateColleges',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::8qKoqZajQ4Vdn6KW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rxUj2uvLAGprRGY7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/soft-skills',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:soft_skills',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::rxUj2uvLAGprRGY7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HT2yvMrbqIE05mCh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/soft-skills',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:soft_skills',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::HT2yvMrbqIE05mCh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3GBQ6Kcf2IrnX48m' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/soft-skills/{softSkillAssessment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:soft_skills',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::3GBQ6Kcf2IrnX48m',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GpklFjIgs9WUsVtA' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/soft-skills/{softSkillAssessment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:soft_skills',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::GpklFjIgs9WUsVtA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kLCNji8bYtjbsFHY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/soft-skills/{softSkillAssessment}/questions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:soft_skills',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillController@questions',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillController@questions',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::kLCNji8bYtjbsFHY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hVS10TKY3K4hzDWi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/soft-skills/{softSkillAssessment}/questions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:soft_skills',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillController@storeQuestion',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillController@storeQuestion',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::hVS10TKY3K4hzDWi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Zipk5hTUfDFgpIjv' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/soft-skills/{softSkillAssessment}/questions/{assessmentQuestion}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:soft_skills',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillController@destroyQuestion',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillController@destroyQuestion',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::Zipk5hTUfDFgpIjv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fYKV8xCqTNEOsABj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/soft-skills/{softSkillAssessment}/questions/auto-fill',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:soft_skills',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillController@autoFillQuestions',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillController@autoFillQuestions',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::fYKV8xCqTNEOsABj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rOQJtvnNJUEsvkKV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/soft-skill-question-bank',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:soft_skills',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillQuestionBankController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillQuestionBankController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::rOQJtvnNJUEsvkKV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nqhmsqpjAkgtuaPk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/soft-skill-question-bank',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:soft_skills',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillQuestionBankController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillQuestionBankController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::nqhmsqpjAkgtuaPk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Llz6H6o2CnBsLDXv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/soft-skill-question-bank/generate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:soft_skills',
          4 => 'throttle:ai-generation',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillQuestionBankController@generate',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillQuestionBankController@generate',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::Llz6H6o2CnBsLDXv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FzSZbyMGFmmYxHpK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/soft-skill-question-bank/{softSkillQuestion}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:soft_skills',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillQuestionBankController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillQuestionBankController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::FzSZbyMGFmmYxHpK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PmGZ7VS0fkpWfgz7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/talent-pool/colleges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:talent_pool',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminTalentPoolController@colleges',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminTalentPoolController@colleges',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::PmGZ7VS0fkpWfgz7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XIGCQM3pLMFpNGp5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/talent-pool/candidates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:talent_pool',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminTalentPoolController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminTalentPoolController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::XIGCQM3pLMFpNGp5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PrdnegyzrovP2ElN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/talent-pool/candidates/{candidate}/visibility',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:talent_pool',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminTalentPoolController@updateVisibility',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminTalentPoolController@updateVisibility',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::PrdnegyzrovP2ElN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sknleJrPiYFwlJ1o' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/article-topics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:articles',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminArticleTopicController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminArticleTopicController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::sknleJrPiYFwlJ1o',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Rtd1WNzmTgJeMytx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/article-topics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:articles',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminArticleTopicController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminArticleTopicController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::Rtd1WNzmTgJeMytx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ivHLKhNtqI9icprM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/article-topics/{articleTopic}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:articles',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminArticleTopicController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminArticleTopicController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::ivHLKhNtqI9icprM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3XyvWWLBVU8KjCzi' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/article-topics/{articleTopic}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:articles',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminArticleTopicController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminArticleTopicController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::3XyvWWLBVU8KjCzi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IgxzK3XK1et1bvHm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/articles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:articles',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminArticleController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminArticleController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::IgxzK3XK1et1bvHm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xdOmUKyHjEJ5C6Jq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/articles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:articles',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminArticleController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminArticleController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::xdOmUKyHjEJ5C6Jq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UoY2aW6SRJsZesSR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/articles/{article}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:articles',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminArticleController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminArticleController@show',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::UoY2aW6SRJsZesSR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ORnGoeDTxWRS1SvQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/articles/{article}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:articles',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminArticleController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminArticleController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::ORnGoeDTxWRS1SvQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SPKeMmIo0B3CMGDM' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/articles/{article}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:articles',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminArticleController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminArticleController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::SPKeMmIo0B3CMGDM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WftgqyP2iSr5XULZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/problems',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:problem_bank',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminProblemController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminProblemController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::WftgqyP2iSr5XULZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2u2798B2AGst24hA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/problems',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:problem_bank',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminProblemController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminProblemController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::2u2798B2AGst24hA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NEESLSz8ZtOF2tgw' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/admin/problems/{problem}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:problem_bank',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminProblemController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminProblemController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::NEESLSz8ZtOF2tgw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6qdRX0bNJm2uxDdC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/customers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:customers',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InternalCustomerController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\InternalCustomerController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::6qdRX0bNJm2uxDdC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HpNv9PXZCrNoGJzM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/customers/{customer}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:customers',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InternalCustomerController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\InternalCustomerController@show',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::HpNv9PXZCrNoGJzM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::l5xmrbxB0M1ez2se' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/customers/{customer}/notes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,superadmin',
          3 => 'permission:customers',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InternalCustomerController@storeNote',
        'controller' => 'App\\Http\\Controllers\\Api\\InternalCustomerController@storeNote',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::l5xmrbxB0M1ez2se',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mUSXDea0vFKy3nMk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/superadmin/overview',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:superadmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SuperAdminController@overview',
        'controller' => 'App\\Http\\Controllers\\Api\\SuperAdminController@overview',
        'namespace' => NULL,
        'prefix' => 'api/superadmin',
        'where' => 
        array (
        ),
        'as' => 'generated::mUSXDea0vFKy3nMk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pQP7qTXRS8IikFMu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/superadmin/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:superadmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SuperAdminController@users',
        'controller' => 'App\\Http\\Controllers\\Api\\SuperAdminController@users',
        'namespace' => NULL,
        'prefix' => 'api/superadmin',
        'where' => 
        array (
        ),
        'as' => 'generated::pQP7qTXRS8IikFMu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TVrjeIRwWOCGvF7U' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/superadmin/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:superadmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SuperAdminController@storeUser',
        'controller' => 'App\\Http\\Controllers\\Api\\SuperAdminController@storeUser',
        'namespace' => NULL,
        'prefix' => 'api/superadmin',
        'where' => 
        array (
        ),
        'as' => 'generated::TVrjeIRwWOCGvF7U',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::L7098BVBzxwIFCPU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/superadmin/users/{user}/detail',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:superadmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SuperAdminController@showUser',
        'controller' => 'App\\Http\\Controllers\\Api\\SuperAdminController@showUser',
        'namespace' => NULL,
        'prefix' => 'api/superadmin',
        'where' => 
        array (
        ),
        'as' => 'generated::L7098BVBzxwIFCPU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vmoaZJx2lZB0KtFs' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/superadmin/users/{user}/toggle-block',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:superadmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SuperAdminController@toggleBlock',
        'controller' => 'App\\Http\\Controllers\\Api\\SuperAdminController@toggleBlock',
        'namespace' => NULL,
        'prefix' => 'api/superadmin',
        'where' => 
        array (
        ),
        'as' => 'generated::vmoaZJx2lZB0KtFs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::q8q2nDJCae4HyKcw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/superadmin/users/{user}/permissions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:superadmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SuperAdminController@updatePermissions',
        'controller' => 'App\\Http\\Controllers\\Api\\SuperAdminController@updatePermissions',
        'namespace' => NULL,
        'prefix' => 'api/superadmin',
        'where' => 
        array (
        ),
        'as' => 'generated::q8q2nDJCae4HyKcw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OZNCAYJwyC0ZyIbs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/superadmin/marketing-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:superadmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SuperAdminController@marketingPerformance',
        'controller' => 'App\\Http\\Controllers\\Api\\SuperAdminController@marketingPerformance',
        'namespace' => NULL,
        'prefix' => 'api/superadmin',
        'where' => 
        array (
        ),
        'as' => 'generated::OZNCAYJwyC0ZyIbs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jRIbjuONsWlaXcSP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/superadmin/audit-logs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:superadmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SuperAdminController@auditLogs',
        'controller' => 'App\\Http\\Controllers\\Api\\SuperAdminController@auditLogs',
        'namespace' => NULL,
        'prefix' => 'api/superadmin',
        'where' => 
        array (
        ),
        'as' => 'generated::jRIbjuONsWlaXcSP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LmVuTWRtEX2lSUA1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/superadmin/judge-nodes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:superadmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SuperAdminController@judgeNodes',
        'controller' => 'App\\Http\\Controllers\\Api\\SuperAdminController@judgeNodes',
        'namespace' => NULL,
        'prefix' => 'api/superadmin',
        'where' => 
        array (
        ),
        'as' => 'generated::LmVuTWRtEX2lSUA1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PdgTj01TEEcGuXiE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/superadmin/feature-flags',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:superadmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SuperAdminController@featureFlags',
        'controller' => 'App\\Http\\Controllers\\Api\\SuperAdminController@featureFlags',
        'namespace' => NULL,
        'prefix' => 'api/superadmin',
        'where' => 
        array (
        ),
        'as' => 'generated::PdgTj01TEEcGuXiE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2DpnUKGNhF5hiNND' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/superadmin/feature-flags/{flag}/toggle',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:superadmin',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SuperAdminController@toggleFeatureFlag',
        'controller' => 'App\\Http\\Controllers\\Api\\SuperAdminController@toggleFeatureFlag',
        'namespace' => NULL,
        'prefix' => 'api/superadmin',
        'where' => 
        array (
        ),
        'as' => 'generated::2DpnUKGNhF5hiNND',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wm4NTBCWJmLNJnBW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/marketing/leads',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_marketing,superadmin',
          3 => 'permission:leads',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\MarketingLeadController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\MarketingLeadController@index',
        'namespace' => NULL,
        'prefix' => 'api/marketing',
        'where' => 
        array (
        ),
        'as' => 'generated::wm4NTBCWJmLNJnBW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::O21kqXnekrMuzqZZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/marketing/leads/{lead}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_marketing,superadmin',
          3 => 'permission:leads',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\MarketingLeadController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\MarketingLeadController@show',
        'namespace' => NULL,
        'prefix' => 'api/marketing',
        'where' => 
        array (
        ),
        'as' => 'generated::O21kqXnekrMuzqZZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::s66ybUxZjzmQKXT6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/marketing/leads/{lead}/status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_marketing,superadmin',
          3 => 'permission:leads',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\MarketingLeadController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Api\\MarketingLeadController@updateStatus',
        'namespace' => NULL,
        'prefix' => 'api/marketing',
        'where' => 
        array (
        ),
        'as' => 'generated::s66ybUxZjzmQKXT6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DtEvaiyjHAM7qD4V' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/marketing/leads/{lead}/notes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_marketing,superadmin',
          3 => 'permission:leads',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\MarketingLeadController@storeNote',
        'controller' => 'App\\Http\\Controllers\\Api\\MarketingLeadController@storeNote',
        'namespace' => NULL,
        'prefix' => 'api/marketing',
        'where' => 
        array (
        ),
        'as' => 'generated::DtEvaiyjHAM7qD4V',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::smiYnJlBtZFYxocq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/marketing/contact-requests',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_marketing,superadmin',
          3 => 'permission:leads',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\MarketingContactRequestController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\MarketingContactRequestController@index',
        'namespace' => NULL,
        'prefix' => 'api/marketing',
        'where' => 
        array (
        ),
        'as' => 'generated::smiYnJlBtZFYxocq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::d53ZFcpGDadmE4iu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/marketing/contact-requests/{contactRequest}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_marketing,superadmin',
          3 => 'permission:leads',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\MarketingContactRequestController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\MarketingContactRequestController@show',
        'namespace' => NULL,
        'prefix' => 'api/marketing',
        'where' => 
        array (
        ),
        'as' => 'generated::d53ZFcpGDadmE4iu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BJAttMQiAAeZh9tx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/marketing/contact-requests/{contactRequest}/status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_marketing,superadmin',
          3 => 'permission:leads',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\MarketingContactRequestController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Api\\MarketingContactRequestController@updateStatus',
        'namespace' => NULL,
        'prefix' => 'api/marketing',
        'where' => 
        array (
        ),
        'as' => 'generated::BJAttMQiAAeZh9tx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WYVKhQPHoVtMO5vu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/marketing/contact-requests/{contactRequest}/notes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_marketing,superadmin',
          3 => 'permission:leads',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\MarketingContactRequestController@storeNote',
        'controller' => 'App\\Http\\Controllers\\Api\\MarketingContactRequestController@storeNote',
        'namespace' => NULL,
        'prefix' => 'api/marketing',
        'where' => 
        array (
        ),
        'as' => 'generated::WYVKhQPHoVtMO5vu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::f5qPeVt0FyJ3rPz9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/marketing/leads/notify',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_marketing,superadmin',
          3 => 'permission:lead_outreach',
        ),
        'uses' => '\\App\\Http\\Controllers\\Api\\MarketingLeadController@notify',
        'controller' => '\\App\\Http\\Controllers\\Api\\MarketingLeadController@notify',
        'namespace' => NULL,
        'prefix' => 'api/marketing',
        'where' => 
        array (
        ),
        'as' => 'generated::f5qPeVt0FyJ3rPz9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BXhGAOck7c04ebRV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/drives/mapped',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoDriveController@mapped',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoDriveController@mapped',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::BXhGAOck7c04ebRV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RNWHLCBoF4RAI0xm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/drives/available',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoDriveController@available',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoDriveController@available',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::RNWHLCBoF4RAI0xm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hLlwU5ZrdHgsh8MY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/drives/pending',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoDriveController@pending',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoDriveController@pending',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::hLlwU5ZrdHgsh8MY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BprpFw3DHK8PMFaJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/drives',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoDriveController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoDriveController@store',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::BprpFw3DHK8PMFaJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EaNL8Pe1S7frcahV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/drives/{placementDrive}/map',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoDriveController@map',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoDriveController@map',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::EaNL8Pe1S7frcahV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ktjbdlxzmsE9bZdJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/drives/{placementDrive}/mapping',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoDriveController@updateMapping',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoDriveController@updateMapping',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::ktjbdlxzmsE9bZdJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::b8ZqylLxpiMnaqRJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/drives/{placementDrive}/unmap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoDriveController@unmap',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoDriveController@unmap',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::b8ZqylLxpiMnaqRJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uveAuBqvR344BwSu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/drives/{placementDrive}/respond',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoDriveController@respond',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoDriveController@respond',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::uveAuBqvR344BwSu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zR8rMoQndkgnYf5P' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/companies/search',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoDriveController@searchCompanies',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoDriveController@searchCompanies',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::zR8rMoQndkgnYf5P',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pHJYBXWPOmwCL5KF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/students/import-template',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentImportController@template',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentImportController@template',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::pHJYBXWPOmwCL5KF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SaCYXYSM5ofWwrEj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/students/import',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentImportController@storeMine',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentImportController@storeMine',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::SaCYXYSM5ofWwrEj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Sg8JXdYipqFFcDjb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/students/imports',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentImportController@indexMine',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentImportController@indexMine',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::Sg8JXdYipqFFcDjb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::G9Tmu0jh36CPSzRn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/students/imports/{studentImport}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentImportController@showMine',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentImportController@showMine',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::G9Tmu0jh36CPSzRn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CTc1Vw1vtIzI5Y6x' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/students/cohort',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoStudentController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoStudentController@index',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::CTc1Vw1vtIzI5Y6x',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HAQKXzCCLnn7NIrv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/students',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoStudentController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoStudentController@store',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::HAQKXzCCLnn7NIrv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1pnw7cPDTpkkoKyR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/students/bulk-notify',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoStudentController@bulkNotify',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoStudentController@bulkNotify',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::1pnw7cPDTpkkoKyR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0huYIi2X5McnGPoO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/students/{student}/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoStudentReportController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoStudentReportController@show',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::0huYIi2X5McnGPoO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::i61A9jdIEBEZobPR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/students/{student}/submissions/{submission}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoStudentReportController@submission',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoStudentReportController@submission',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::i61A9jdIEBEZobPR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VJ9E00lCBnHZOCq5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/students/{student}/contest-submissions/{contestSubmission}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoStudentReportController@contestSubmission',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoStudentReportController@contestSubmission',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::VJ9E00lCBnHZOCq5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7XTLnzPE1zUIpDIe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/coordinators',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoCoordinatorController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoCoordinatorController@index',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::7XTLnzPE1zUIpDIe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xI2lKbYVzwm4cWxE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/coordinators',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoCoordinatorController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoCoordinatorController@store',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::xI2lKbYVzwm4cWxE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vsrjyQ5zEbYZAseH' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/tpo/coordinators/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoCoordinatorController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoCoordinatorController@update',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::vsrjyQ5zEbYZAseH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MakyAbPBBnwKzZGR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/coordinators/{user}/toggle-block',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoCoordinatorController@toggleBlock',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoCoordinatorController@toggleBlock',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::MakyAbPBBnwKzZGR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DDaYy9FDHpSlm3FW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/soft-skills',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoSoftSkillController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoSoftSkillController@index',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::DDaYy9FDHpSlm3FW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mRINjcqxxPrtJj7I' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/soft-skills',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoSoftSkillController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoSoftSkillController@store',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::mRINjcqxxPrtJj7I',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8udhIDRTmuu9LMo0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/soft-skills/{softSkillAssessment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoSoftSkillController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoSoftSkillController@update',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::8udhIDRTmuu9LMo0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EvFGhX30qIuUX1AI' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/tpo/soft-skills/{softSkillAssessment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoSoftSkillController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoSoftSkillController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::EvFGhX30qIuUX1AI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HXNS0HE0JOxdjjQA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/soft-skills/{softSkillAssessment}/questions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoSoftSkillController@questions',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoSoftSkillController@questions',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::HXNS0HE0JOxdjjQA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7UmHp0t1N3tWtBZW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/soft-skills/{softSkillAssessment}/questions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoSoftSkillController@storeQuestion',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoSoftSkillController@storeQuestion',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::7UmHp0t1N3tWtBZW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hxSeOAhzH2SytpaN' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/tpo/soft-skills/{softSkillAssessment}/questions/{assessmentQuestion}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoSoftSkillController@destroyQuestion',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoSoftSkillController@destroyQuestion',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::hxSeOAhzH2SytpaN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cwRUxdIu0S6P6r21' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/soft-skills/{softSkillAssessment}/questions/auto-fill',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoSoftSkillController@autoFillQuestions',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoSoftSkillController@autoFillQuestions',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::cwRUxdIu0S6P6r21',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AGcZXZwKlX9qwwzM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/soft-skill-question-bank',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillQuestionBankController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillQuestionBankController@index',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::AGcZXZwKlX9qwwzM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Wjdn7zKqETdWoEVR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/soft-skill-question-bank/generate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
          3 => 'throttle:ai-generation',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillQuestionBankController@generate',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillQuestionBankController@generate',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::Wjdn7zKqETdWoEVR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RGQ7acc02DQKbbU1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/reports/data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoReportsController@data',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoReportsController@data',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::RGQ7acc02DQKbbU1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SlxNnxM32ggezJE1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/placement-target',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoReportsController@updateTarget',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoReportsController@updateTarget',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::SlxNnxM32ggezJE1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GeS5vqHOfuanApVY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/proctoring',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoProctoringController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoProctoringController@index',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::GeS5vqHOfuanApVY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3IlR2Iox4Oh4m7vm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/proctoring/{proctoringSession}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoProctoringController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoProctoringController@show',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::3IlR2Iox4Oh4m7vm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hu7mqkPe0OwlNtNA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/proctoring/{proctoringSession}/reinstate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoProctoringController@reinstate',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoProctoringController@reinstate',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::hu7mqkPe0OwlNtNA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lPr4mbeiwOlBYM1Z' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/drives/{placementDrive}/applications',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoDriveApplicationController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoDriveApplicationController@index',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::lPr4mbeiwOlBYM1Z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2f6JRH6Gr2loxxzl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/drives/{placementDrive}/applications',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoDriveApplicationController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoDriveApplicationController@store',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::2f6JRH6Gr2loxxzl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vDLCxSQVVtIv2oLb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/drives/{placementDrive}/applications/bulk-register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoDriveApplicationController@bulkRegister',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoDriveApplicationController@bulkRegister',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::vDLCxSQVVtIv2oLb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qFEGsUb8d6cXYMCy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/drives/{placementDrive}/applications/{application}/stage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoDriveApplicationController@updateStage',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoDriveApplicationController@updateStage',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::qFEGsUb8d6cXYMCy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gTByhffMMfPY6SqG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/contests',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoContestController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoContestController@index',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::gTByhffMMfPY6SqG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fO6K6bCR5ehAfzgY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/contests',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoContestController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoContestController@store',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::fO6K6bCR5ehAfzgY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MJhgje3ap3GulsgY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/contests/{contest}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoContestController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoContestController@update',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::MJhgje3ap3GulsgY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::D8mH1XFJh1SRpYjL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/contests/{contest}/problems',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoContestController@problems',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoContestController@problems',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::D8mH1XFJh1SRpYjL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0Nn3bWbKcbBEkwea' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/contests/{contest}/problems',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoContestController@storeProblem',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoContestController@storeProblem',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::0Nn3bWbKcbBEkwea',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tKANpahsHKifn1sw' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/tpo/contests/{contest}/problems/{contestProblem}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoContestController@destroyProblem',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoContestController@destroyProblem',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::tKANpahsHKifn1sw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::m6lb5zO6k77ptQko' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/contests/{contest}/finalize',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoContestController@finalize',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoContestController@finalize',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::m6lb5zO6k77ptQko',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fChF1kRKKDUH3FUe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/contests/{contest}/participants',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoContestController@participants',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoContestController@participants',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::fChF1kRKKDUH3FUe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jIGvGxKtD1q1AFSZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/contests/{contest}/participants/{student}/submissions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoContestController@participantSubmissions',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoContestController@participantSubmissions',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::jIGvGxKtD1q1AFSZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5DYcuiTBnzcBhsE5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/interviews',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@index',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::5DYcuiTBnzcBhsE5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SazlB3IKYvFGSl9z' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/interviews',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@store',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::SazlB3IKYvFGSl9z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::idj5UkNETOI1fr5H' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/interviews/{interview}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@update',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::idj5UkNETOI1fr5H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DQoPEeCQDfbswlCV' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/tpo/interviews/{interview}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::DQoPEeCQDfbswlCV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::65IhnaLr6E9WQCKH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/interviews/{interview}/questions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@questions',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@questions',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::65IhnaLr6E9WQCKH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ieGi32Xm0U4Uqgwn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/interviews/{interview}/questions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@storeQuestion',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@storeQuestion',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::ieGi32Xm0U4Uqgwn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::n5NGNwSkjPO1kmU4' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/tpo/interviews/{interview}/questions/{interviewQuestion}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@destroyQuestion',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@destroyQuestion',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::n5NGNwSkjPO1kmU4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yjX6aeoHm15OgXuI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/interviews/{interview}/sessions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@sessions',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@sessions',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::yjX6aeoHm15OgXuI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Nc2pydHjG5MVp1ml' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/interviews/{interview}/sessions/{interviewSession}/responses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@responses',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@responses',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::Nc2pydHjG5MVp1ml',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qtoGuXMw6yQVAxuT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/interviews/{interview}/responses/{interviewResponse}/audio',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@responseAudio',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@responseAudio',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::qtoGuXMw6yQVAxuT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EUCGkkjPaQ0n5F9C' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/interviews/{interview}/sessions/{interviewSession}/reinstate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@reinstateProctoring',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@reinstateProctoring',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::EUCGkkjPaQ0n5F9C',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PxqhecKc2ab8OPft' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/interviews/{interview}/responses/{interviewResponse}/score',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@scoreResponse',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@scoreResponse',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::PxqhecKc2ab8OPft',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZyfzCoUNc1SBHzXL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/interviews/{interview}/sessions/{interviewSession}/finalize',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@finalizeSession',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewController@finalizeSession',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::ZyfzCoUNc1SBHzXL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pLrjlk3BvaQw1psG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/interview-role-templates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewRoleTemplateController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewRoleTemplateController@index',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::pLrjlk3BvaQw1psG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aAvsVjNChujRs0wr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/interview-role-templates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewRoleTemplateController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewRoleTemplateController@store',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::aAvsVjNChujRs0wr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TdjBzGUWtGhca6n1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/interview-role-templates/{interviewRoleTemplate}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewRoleTemplateController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewRoleTemplateController@update',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::TdjBzGUWtGhca6n1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WNLqFGRJaBGOdMmr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tpo/interview-tracks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewTrackController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewTrackController@index',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::WNLqFGRJaBGOdMmr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GwZLChTN8hmikP45' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/interview-tracks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewTrackController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewTrackController@store',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::GwZLChTN8hmikP45',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kdD6FXpuRuejENhk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tpo/interview-tracks/{interviewTrack}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewTrackController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewTrackController@update',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::kdD6FXpuRuejENhk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::i1Y02g8OnQu6yJUB' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/tpo/interview-tracks/{interviewTrack}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_tpo',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TpoInterviewTrackController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\TpoInterviewTrackController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/tpo',
        'where' => 
        array (
        ),
        'as' => 'generated::i1Y02g8OnQu6yJUB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Q2lVzsSNP84JUlGr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/colleges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyCollegeController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyCollegeController@index',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::Q2lVzsSNP84JUlGr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eAq1lZgVdzB64C7v' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/drives',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyDriveController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyDriveController@index',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::eAq1lZgVdzB64C7v',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IKRoVHwJPk0uHMMR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/drives',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyDriveController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyDriveController@store',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::IKRoVHwJPk0uHMMR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LPTFFFrnlU7DjaCZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/drives/{placementDrive}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyDriveController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyDriveController@show',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::LPTFFFrnlU7DjaCZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NjrRPWTtGiPiRfCc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/drives/{placementDrive}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyDriveController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyDriveController@update',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::NjrRPWTtGiPiRfCc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mv55b6BPu7Yzf3WW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/drives/{placementDrive}/propose',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyDriveController@proposeToColleges',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyDriveController@proposeToColleges',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::mv55b6BPu7Yzf3WW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aVbFJN8fDrg8N3tH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/drives/{placementDrive}/mappings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyDriveController@mappings',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyDriveController@mappings',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::aVbFJN8fDrg8N3tH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bQzchsQzJOYYB12Q' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/drives/{placementDrive}/candidates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyCandidateController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyCandidateController@index',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::bQzchsQzJOYYB12Q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1dLB0WTZXLzvQ0KZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/drives/{placementDrive}/candidates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyCandidateController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyCandidateController@store',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::1dLB0WTZXLzvQ0KZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aueq3mvCNV5jWMHu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/drives/{placementDrive}/candidates/{application}/stage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyCandidateController@updateStage',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyCandidateController@updateStage',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::aueq3mvCNV5jWMHu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dGnBMSvKnTGV87um' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/candidates/import-template',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyCandidateController@template',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyCandidateController@template',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::dGnBMSvKnTGV87um',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sLWBmYSHRptLQADA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/drives/{placementDrive}/candidates/import',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyCandidateController@import',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyCandidateController@import',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::sLWBmYSHRptLQADA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fu6KHjp10I2AQ7Ar' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/drives/{placementDrive}/candidates/imports',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyCandidateController@indexImports',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyCandidateController@indexImports',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::fu6KHjp10I2AQ7Ar',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TnIsGRDv2260niC9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/drives/{placementDrive}/candidates/imports/{candidateImport}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyCandidateController@showImport',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyCandidateController@showImport',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::TnIsGRDv2260niC9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CBysIcb3obzeJ4s7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/contests',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyContestController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyContestController@index',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::CBysIcb3obzeJ4s7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QNPs5yUsx2iTCmHx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/contests',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyContestController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyContestController@store',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::QNPs5yUsx2iTCmHx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UfJXGYiFsELMsWcI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/contests/{contest}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyContestController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyContestController@update',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::UfJXGYiFsELMsWcI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::j2jeBW4anrkGATC8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/contests/{contest}/problems',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyContestController@problems',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyContestController@problems',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::j2jeBW4anrkGATC8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AWbmHGOT3xZJbBQq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/contests/{contest}/problems',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyContestController@storeProblem',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyContestController@storeProblem',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::AWbmHGOT3xZJbBQq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2ccoR0KluB8gxUYR' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/company/contests/{contest}/problems/{contestProblem}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyContestController@destroyProblem',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyContestController@destroyProblem',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::2ccoR0KluB8gxUYR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZJ7zlk1SQkuiiAfD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/contests/{contest}/finalize',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyContestController@finalize',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyContestController@finalize',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::ZJ7zlk1SQkuiiAfD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kzCGQd53u2Qv7mHN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/contests/{contest}/invite',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyContestController@inviteCandidates',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyContestController@inviteCandidates',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::kzCGQd53u2Qv7mHN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2UX5fiTUPP5qoNzb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/contests/{contest}/invited',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyContestController@invited',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyContestController@invited',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::2UX5fiTUPP5qoNzb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aprR91nq6HXKnTdG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/contests/{contest}/results',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyContestController@results',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyContestController@results',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::aprR91nq6HXKnTdG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gtV1kCo6Y8CyPpOH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/contests/{contest}/results/import',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyContestController@importResults',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyContestController@importResults',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::gtV1kCo6Y8CyPpOH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4yj4BmRd3E7W9CyQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/interviews',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@index',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::4yj4BmRd3E7W9CyQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LHzVXPR1rTmrNNto' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/interviews',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@store',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::LHzVXPR1rTmrNNto',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IeD7RbT8RMB44avb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/interviews/{interview}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@update',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::IeD7RbT8RMB44avb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RgILmeF5mSu5EYD6' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/company/interviews/{interview}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::RgILmeF5mSu5EYD6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::n4vTnQOSBkMQCHhE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/interviews/{interview}/questions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@questions',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@questions',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::n4vTnQOSBkMQCHhE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::P5zdM30fZawtVCKh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/interviews/{interview}/questions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@storeQuestion',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@storeQuestion',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::P5zdM30fZawtVCKh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1fjA9MAytO1bxP4Y' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/company/interviews/{interview}/questions/{interviewQuestion}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@destroyQuestion',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@destroyQuestion',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::1fjA9MAytO1bxP4Y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wWar4rONTcFxADNE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/interviews/{interview}/invite',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@inviteCandidates',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@inviteCandidates',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::wWar4rONTcFxADNE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hbltgLU0d2hl18HS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/interviews/{interview}/invited',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@invited',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@invited',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::hbltgLU0d2hl18HS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UXr0reyzpab920OI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/interviews/{interview}/sessions/{interviewSession}/responses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@responses',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@responses',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::UXr0reyzpab920OI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NMvFKMf0hWNDm2mK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/interviews/{interview}/responses/{interviewResponse}/audio',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@responseAudio',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@responseAudio',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::NMvFKMf0hWNDm2mK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jP4wpxQGMmlv3qfO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/interviews/{interview}/sessions/{interviewSession}/reinstate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@reinstateProctoring',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@reinstateProctoring',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::jP4wpxQGMmlv3qfO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Jqqe7Ns2aHKx07tt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/interviews/{interview}/responses/{interviewResponse}/score',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@scoreResponse',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@scoreResponse',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::Jqqe7Ns2aHKx07tt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::J5ACanVR2RhWBNCB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/interviews/{interview}/sessions/{interviewSession}/finalize',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@finalizeSession',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewController@finalizeSession',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::J5ACanVR2RhWBNCB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::urAC82dlsKQZAAKU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/interview-role-templates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewRoleTemplateController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewRoleTemplateController@index',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::urAC82dlsKQZAAKU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YuHwoS1uyuBn4Iz2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/interview-role-templates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewRoleTemplateController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewRoleTemplateController@store',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::YuHwoS1uyuBn4Iz2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cki7U3ctY3zZcSSY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/interview-role-templates/{interviewRoleTemplate}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewRoleTemplateController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewRoleTemplateController@update',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::cki7U3ctY3zZcSSY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dv5OJHN5KXJyh5u0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/interview-tracks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewTrackController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewTrackController@index',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::dv5OJHN5KXJyh5u0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mMOeVMlQfHTqVz3d' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/interview-tracks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewTrackController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewTrackController@store',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::mMOeVMlQfHTqVz3d',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::w2R9shcdjkhEU7OP' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/interview-tracks/{interviewTrack}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewTrackController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewTrackController@update',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::w2R9shcdjkhEU7OP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zIxIGrQTjtSfy27Q' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/company/interview-tracks/{interviewTrack}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInterviewTrackController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInterviewTrackController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::zIxIGrQTjtSfy27Q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mIaiyq5EtTEnhZSQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/proctoring',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyProctoringController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyProctoringController@index',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::mIaiyq5EtTEnhZSQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PR0hr19ht90mEgJQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/proctoring/{proctoringSession}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyProctoringController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyProctoringController@show',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::PR0hr19ht90mEgJQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CBHxBQFBVWmqpCVk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/proctoring/{proctoringSession}/reinstate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyProctoringController@reinstate',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyProctoringController@reinstate',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::CBHxBQFBVWmqpCVk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2OQk0khaU0ADE3L1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/reports/data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyReportsController@data',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyReportsController@data',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::2OQk0khaU0ADE3L1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RZW3rl2JS9HSIr3y' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/talent-pool',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyTalentPoolController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyTalentPoolController@index',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::RZW3rl2JS9HSIr3y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CrESZdH76PysiS7Y' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/talent-pool/inquiries',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyTalentPoolController@myInquiries',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyTalentPoolController@myInquiries',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::CrESZdH76PysiS7Y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SvqV571XpFw59vcv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/talent-pool/{candidate}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyTalentPoolController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyTalentPoolController@show',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::SvqV571XpFw59vcv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YHjrFVsjtive4Kus' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/talent-pool/{candidate}/resume',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyTalentPoolController@resume',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyTalentPoolController@resume',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::YHjrFVsjtive4Kus',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yEzaddhtzZooDo7k' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/talent-pool/{candidate}/interest',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyTalentPoolController@expressInterest',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyTalentPoolController@expressInterest',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::yEzaddhtzZooDo7k',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Cy8xZYFWjXKGwj8n' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/talent-pool/{candidate}/interview',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyTalentPoolController@scheduleInterview',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyTalentPoolController@scheduleInterview',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::Cy8xZYFWjXKGwj8n',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tgxA1ifDzBgSndyk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/talent-pool/{candidate}/hire',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyTalentPoolController@hire',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyTalentPoolController@hire',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::tgxA1ifDzBgSndyk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JLZTjGQBXfKgrvcV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/talent-pool/{candidate}/notify',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyTalentPoolController@notify',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyTalentPoolController@notify',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::JLZTjGQBXfKgrvcV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KmkebXYFi7k9syrR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/soft-skills',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanySoftSkillController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanySoftSkillController@index',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::KmkebXYFi7k9syrR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zBgmGqbOmZfCte3u' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/soft-skills',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanySoftSkillController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanySoftSkillController@store',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::zBgmGqbOmZfCte3u',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pIFZ31jLvlySLmQp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/soft-skills/{softSkillAssessment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanySoftSkillController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanySoftSkillController@update',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::pIFZ31jLvlySLmQp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0dcGVB8awJ851x4K' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/company/soft-skills/{softSkillAssessment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanySoftSkillController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanySoftSkillController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::0dcGVB8awJ851x4K',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TXbnFQ1wOzBix2e9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/soft-skills/{softSkillAssessment}/questions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanySoftSkillController@questions',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanySoftSkillController@questions',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::TXbnFQ1wOzBix2e9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::k2oAumhnTiUzQbhj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/soft-skills/{softSkillAssessment}/questions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanySoftSkillController@storeQuestion',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanySoftSkillController@storeQuestion',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::k2oAumhnTiUzQbhj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wRbP68A7y9fIBAc0' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/company/soft-skills/{softSkillAssessment}/questions/{assessmentQuestion}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanySoftSkillController@destroyQuestion',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanySoftSkillController@destroyQuestion',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::wRbP68A7y9fIBAc0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sBG570Og2Gctwluh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/soft-skills/{softSkillAssessment}/questions/auto-fill',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanySoftSkillController@autoFillQuestions',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanySoftSkillController@autoFillQuestions',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::sBG570Og2Gctwluh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aPFKelHmmr6f6nnm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company/soft-skill-question-bank',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillQuestionBankController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillQuestionBankController@index',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::aPFKelHmmr6f6nnm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rymeWqybLftHJzIV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/soft-skill-question-bank/generate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_company',
          3 => 'throttle:ai-generation',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillQuestionBankController@generate',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminSoftSkillQuestionBankController@generate',
        'namespace' => NULL,
        'prefix' => 'api/company',
        'where' => 
        array (
        ),
        'as' => 'generated::rymeWqybLftHJzIV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a6dXIh2La2124Uiu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/coordinator/students',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:section_coordinator',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CoordinatorStudentController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CoordinatorStudentController@index',
        'namespace' => NULL,
        'prefix' => 'api/coordinator',
        'where' => 
        array (
        ),
        'as' => 'generated::a6dXIh2La2124Uiu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2i0WnWIhUzSl83aw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/coordinator/students/{user}/toggle-block',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:section_coordinator',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CoordinatorStudentController@toggleBlock',
        'controller' => 'App\\Http\\Controllers\\Api\\CoordinatorStudentController@toggleBlock',
        'namespace' => NULL,
        'prefix' => 'api/coordinator',
        'where' => 
        array (
        ),
        'as' => 'generated::2i0WnWIhUzSl83aw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::suzmtg89kZmciqv1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/coordinator/students/bulk-notify',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:section_coordinator',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CoordinatorStudentController@bulkNotify',
        'controller' => 'App\\Http\\Controllers\\Api\\CoordinatorStudentController@bulkNotify',
        'namespace' => NULL,
        'prefix' => 'api/coordinator',
        'where' => 
        array (
        ),
        'as' => 'generated::suzmtg89kZmciqv1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kKh8LlvoiQsPVwZa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/coordinator/students/{student}/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:section_coordinator',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CoordinatorStudentReportController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\CoordinatorStudentReportController@show',
        'namespace' => NULL,
        'prefix' => 'api/coordinator',
        'where' => 
        array (
        ),
        'as' => 'generated::kKh8LlvoiQsPVwZa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ko78xdzmRFU1DHW5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/coordinator/students/{student}/submissions/{submission}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:section_coordinator',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CoordinatorStudentReportController@submission',
        'controller' => 'App\\Http\\Controllers\\Api\\CoordinatorStudentReportController@submission',
        'namespace' => NULL,
        'prefix' => 'api/coordinator',
        'where' => 
        array (
        ),
        'as' => 'generated::Ko78xdzmRFU1DHW5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::moEp30xlq5QMn7Rp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/coordinator/students/{student}/contest-submissions/{contestSubmission}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:section_coordinator',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CoordinatorStudentReportController@contestSubmission',
        'controller' => 'App\\Http\\Controllers\\Api\\CoordinatorStudentReportController@contestSubmission',
        'namespace' => NULL,
        'prefix' => 'api/coordinator',
        'where' => 
        array (
        ),
        'as' => 'generated::moEp30xlq5QMn7Rp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZS7TDJIC3ZrUJI1b' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/coordinator/proctoring',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:section_coordinator',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CoordinatorProctoringController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CoordinatorProctoringController@index',
        'namespace' => NULL,
        'prefix' => 'api/coordinator',
        'where' => 
        array (
        ),
        'as' => 'generated::ZS7TDJIC3ZrUJI1b',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5LjEFrJuOybOXG4u' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/coordinator/proctoring/{proctoringSession}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:section_coordinator',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CoordinatorProctoringController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\CoordinatorProctoringController@show',
        'namespace' => NULL,
        'prefix' => 'api/coordinator',
        'where' => 
        array (
        ),
        'as' => 'generated::5LjEFrJuOybOXG4u',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::g65SgDvMROg16MUh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/coordinator/proctoring/{proctoringSession}/reinstate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:section_coordinator',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CoordinatorProctoringController@reinstate',
        'controller' => 'App\\Http\\Controllers\\Api\\CoordinatorProctoringController@reinstate',
        'namespace' => NULL,
        'prefix' => 'api/coordinator',
        'where' => 
        array (
        ),
        'as' => 'generated::g65SgDvMROg16MUh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ICoLD0JhALWIJrsS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/problems',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user,admin_internal,admin_tpo,superadmin,admin_company',
        ),
        'uses' => '\\App\\Http\\Controllers\\Api\\ProblemController@index',
        'controller' => '\\App\\Http\\Controllers\\Api\\ProblemController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ICoLD0JhALWIJrsS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xlvp57EtxkSBM0Sf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/interview-question-bank/browse',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,admin_tpo,superadmin,admin_company',
        ),
        'uses' => '\\App\\Http\\Controllers\\Api\\InterviewQuestionBankController@index',
        'controller' => '\\App\\Http\\Controllers\\Api\\InterviewQuestionBankController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::xlvp57EtxkSBM0Sf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2UnZp1SNBC5NGUGa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/interview-question-bank/generate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:admin_internal,admin_tpo,superadmin,admin_company',
          3 => 'throttle:ai-generation',
        ),
        'uses' => '\\App\\Http\\Controllers\\Api\\InterviewQuestionGenerationController@generate',
        'controller' => '\\App\\Http\\Controllers\\Api\\InterviewQuestionGenerationController@generate',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::2UnZp1SNBC5NGUGa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uTBDmjz8NgnxPOhT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/drives',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentDriveController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentDriveController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::uTBDmjz8NgnxPOhT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CNzu0Ef36owKvAWf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/drives/{placementDrive}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentDriveController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentDriveController@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::CNzu0Ef36owKvAWf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rSxbg3yjFIakEiTU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/problems/{problem}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ProblemController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\ProblemController@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::rSxbg3yjFIakEiTU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wTZaLgjqZbizTvCb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/problems/{problem}/run',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
          3 => 'throttle:judge-run',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SubmissionController@run',
        'controller' => 'App\\Http\\Controllers\\Api\\SubmissionController@run',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::wTZaLgjqZbizTvCb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ra72F4sXQkL9XiMB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/problems/{problem}/submit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
          3 => 'throttle:judge-submit',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SubmissionController@submit',
        'controller' => 'App\\Http\\Controllers\\Api\\SubmissionController@submit',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::Ra72F4sXQkL9XiMB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hRquWrPyDmLtaWOr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/judge/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
          3 => 'throttle:judge-poll',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\JudgeResultController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\JudgeResultController@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::hRquWrPyDmLtaWOr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2jU7BGLKMmaHRYjV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/submissions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\MySubmissionsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\MySubmissionsController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::2jU7BGLKMmaHRYjV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4fIv9DP9e7CwDruW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/submissions/{submission}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\MySubmissionsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\MySubmissionsController@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::4fIv9DP9e7CwDruW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3BxX5poqK9MDwQTo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/contest-submissions/{contestSubmission}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\MySubmissionsController@contestSubmission',
        'controller' => 'App\\Http\\Controllers\\Api\\MySubmissionsController@contestSubmission',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::3BxX5poqK9MDwQTo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rR2U3cY7Qma03puX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/me/stats',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentStatsController@mine',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentStatsController@mine',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::rR2U3cY7Qma03puX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Gh02BSHX2W2aHivP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/me/rating-history',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentStatsController@ratingHistory',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentStatsController@ratingHistory',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::Gh02BSHX2W2aHivP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MzZjePfPtRZqrtio' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/me/interviews',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InterviewController@history',
        'controller' => 'App\\Http\\Controllers\\Api\\InterviewController@history',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::MzZjePfPtRZqrtio',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tNwNKhlxuwD337xK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/me/soft-skills',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SoftSkillController@history',
        'controller' => 'App\\Http\\Controllers\\Api\\SoftSkillController@history',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::tNwNKhlxuwD337xK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fRVdHFbwA6FlXjcy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/leaderboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\LeaderboardController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\LeaderboardController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::fRVdHFbwA6FlXjcy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5GMe5skC4mI4cE1r' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/contests',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ContestController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\ContestController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::5GMe5skC4mI4cE1r',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TsSVDwU3oMQ1v46T' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/contests/{contest}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ContestController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\ContestController@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::TsSVDwU3oMQ1v46T',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::abZkhYQEdLm0Ybzd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/contests/{contest}/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ContestController@register',
        'controller' => 'App\\Http\\Controllers\\Api\\ContestController@register',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::abZkhYQEdLm0Ybzd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xDa6K2S4FTVXFVt4' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/contests/{contest}/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ContestController@unregister',
        'controller' => 'App\\Http\\Controllers\\Api\\ContestController@unregister',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::xDa6K2S4FTVXFVt4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QWRNL4zHYR3CqEQa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/contests/{contest}/leaderboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ContestController@leaderboard',
        'controller' => 'App\\Http\\Controllers\\Api\\ContestController@leaderboard',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::QWRNL4zHYR3CqEQa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lOSXomwBN43zRi4n' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/contests/{contest}/problems/{contestProblem}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ContestSubmissionController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\ContestSubmissionController@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::lOSXomwBN43zRi4n',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::q9GoF61chP754QtQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/contests/{contest}/problems/{contestProblem}/run',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
          3 => 'throttle:judge-run',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ContestSubmissionController@run',
        'controller' => 'App\\Http\\Controllers\\Api\\ContestSubmissionController@run',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::q9GoF61chP754QtQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sf3IHXKHqL1sMKmh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/contests/{contest}/problems/{contestProblem}/submit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
          3 => 'throttle:judge-submit',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ContestSubmissionController@submit',
        'controller' => 'App\\Http\\Controllers\\Api\\ContestSubmissionController@submit',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::sf3IHXKHqL1sMKmh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2NXrM7vYZKkGovWC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/interviews',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InterviewController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\InterviewController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::2NXrM7vYZKkGovWC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lQd9lVxgwBycd9YY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/interviews/{interview}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InterviewController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\InterviewController@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::lQd9lVxgwBycd9YY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HH9OPcWbmzdH44D6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/interviews/{interview}/start',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InterviewController@start',
        'controller' => 'App\\Http\\Controllers\\Api\\InterviewController@start',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::HH9OPcWbmzdH44D6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OHB5dp3HPFPdHBT8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/interviews/{interview}/answer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InterviewController@answer',
        'controller' => 'App\\Http\\Controllers\\Api\\InterviewController@answer',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::OHB5dp3HPFPdHBT8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CsLj1YS0vZvcwS6R' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/interviews/{interview}/complete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InterviewController@complete',
        'controller' => 'App\\Http\\Controllers\\Api\\InterviewController@complete',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::CsLj1YS0vZvcwS6R',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZPNzdY1DHutCwyPF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/interviews/{interview}/result',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InterviewController@result',
        'controller' => 'App\\Http\\Controllers\\Api\\InterviewController@result',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ZPNzdY1DHutCwyPF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a8vNlbktHkhwU94O' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/interviews/{interview}/responses/{interviewResponse}/audio',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InterviewController@responseAudio',
        'controller' => 'App\\Http\\Controllers\\Api\\InterviewController@responseAudio',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::a8vNlbktHkhwU94O',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CGXNa1NYatQqjQgA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/interviews/{interview}/proctoring/start',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InterviewProctoringController@start',
        'controller' => 'App\\Http\\Controllers\\Api\\InterviewProctoringController@start',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::CGXNa1NYatQqjQgA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lQyKKWkvzAlysYCo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/interviews/{interview}/proctoring/violations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
          3 => 'throttle:proctoring-event',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InterviewProctoringController@reportViolation',
        'controller' => 'App\\Http\\Controllers\\Api\\InterviewProctoringController@reportViolation',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::lQyKKWkvzAlysYCo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mV2HCMGoqI2KRDjb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/soft-skills',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SoftSkillController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\SoftSkillController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::mV2HCMGoqI2KRDjb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9v6oJijk19JjLBBb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/soft-skills/{softSkillAssessment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SoftSkillController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\SoftSkillController@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::9v6oJijk19JjLBBb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::48SI16CgzZxViv6b' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/soft-skills/{softSkillAssessment}/start',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SoftSkillController@start',
        'controller' => 'App\\Http\\Controllers\\Api\\SoftSkillController@start',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::48SI16CgzZxViv6b',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::J4YJM7Ug5FCnHWiM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/soft-skills/sessions/{softSkillSession}/answer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SoftSkillController@answer',
        'controller' => 'App\\Http\\Controllers\\Api\\SoftSkillController@answer',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::J4YJM7Ug5FCnHWiM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4p3T9A2NVAJ3y485' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/soft-skills/sessions/{softSkillSession}/submit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SoftSkillController@submit',
        'controller' => 'App\\Http\\Controllers\\Api\\SoftSkillController@submit',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::4p3T9A2NVAJ3y485',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vKaC6NrjvCCh0ZmF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/soft-skills/sessions/{softSkillSession}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SoftSkillController@viewSession',
        'controller' => 'App\\Http\\Controllers\\Api\\SoftSkillController@viewSession',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::vKaC6NrjvCCh0ZmF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3srXANubiUsJy5zQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/interview-tracks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InterviewTrackController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\InterviewTrackController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::3srXANubiUsJy5zQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IaFsvGL39ZCfqcsr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/interview-tracks/{interviewTrack}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InterviewTrackController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\InterviewTrackController@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::IaFsvGL39ZCfqcsr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mP39NmWNFJWK2S52' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/articles/topics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ArticleController@topics',
        'controller' => 'App\\Http\\Controllers\\Api\\ArticleController@topics',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::mP39NmWNFJWK2S52',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fyQAccCDUxA3Wlrs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/articles/topics/{articleTopic}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ArticleController@topicShow',
        'controller' => 'App\\Http\\Controllers\\Api\\ArticleController@topicShow',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::fyQAccCDUxA3Wlrs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Bdu0ALkYFl4Nh7IK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/articles/{article}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ArticleController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\ArticleController@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::Bdu0ALkYFl4Nh7IK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fC83rdzDcVTEGQA5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/articles/{article}/read',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ArticleController@markRead',
        'controller' => 'App\\Http\\Controllers\\Api\\ArticleController@markRead',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::fC83rdzDcVTEGQA5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Sc9hQ7I8vv5nYHlO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/learning-centre/overview',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\LearningCentreController@overview',
        'controller' => 'App\\Http\\Controllers\\Api\\LearningCentreController@overview',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::Sc9hQ7I8vv5nYHlO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::N1wVAX44vtnu3HDX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/learning-centre/speaking/prompts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SpeakingPracticeController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\SpeakingPracticeController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::N1wVAX44vtnu3HDX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::A4KLgCzisbT9zTdc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/learning-centre/speaking/prompts/{speakingPrompt}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SpeakingPracticeController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\SpeakingPracticeController@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::A4KLgCzisbT9zTdc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IUMELcQHbZQfQtfg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/learning-centre/speaking/prompts/{speakingPrompt}/attempts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
          3 => 'throttle:ai-generation',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SpeakingPracticeController@submit',
        'controller' => 'App\\Http\\Controllers\\Api\\SpeakingPracticeController@submit',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::IUMELcQHbZQfQtfg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6snT2doMteUpvS3w' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/learning-centre/listening/lessons',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ListeningLabController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\ListeningLabController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::6snT2doMteUpvS3w',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uizhX0LZl0eI42iY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/learning-centre/listening/lessons/{listeningLesson}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ListeningLabController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\ListeningLabController@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::uizhX0LZl0eI42iY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JFYifPUQd9zMR5hT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/learning-centre/listening/lessons/{listeningLesson}/attempts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ListeningLabController@submit',
        'controller' => 'App\\Http\\Controllers\\Api\\ListeningLabController@submit',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::JFYifPUQd9zMR5hT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eVJFTmuvd0zrcyv4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/learning-centre/vocabulary/generate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
          3 => 'throttle:ai-generation',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\VocabularyController@generate',
        'controller' => 'App\\Http\\Controllers\\Api\\VocabularyController@generate',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::eVJFTmuvd0zrcyv4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZXRxFrGDkZIUSz7G' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/learning-centre/vocabulary/attempts/{vocabularyAttempt}/submit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\VocabularyController@submit',
        'controller' => 'App\\Http\\Controllers\\Api\\VocabularyController@submit',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ZXRxFrGDkZIUSz7G',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xsxRWb3pHrD8i1OU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/contests/{contest}/problems/{contestProblem}/proctoring/start',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ContestProctoringController@start',
        'controller' => 'App\\Http\\Controllers\\Api\\ContestProctoringController@start',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::xsxRWb3pHrD8i1OU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KeSzhbKIovHy44LC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/contests/{contest}/problems/{contestProblem}/proctoring/violations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
          3 => 'throttle:proctoring-event',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ContestProctoringController@reportViolation',
        'controller' => 'App\\Http\\Controllers\\Api\\ContestProctoringController@reportViolation',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::KeSzhbKIovHy44LC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pbwoav1PsfUEOrOI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/me/talent-pool',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentTalentPoolController@mine',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentTalentPoolController@mine',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::pbwoav1PsfUEOrOI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cNIiYFO77r9KCJbU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/me/talent-pool/opt-in',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentTalentPoolController@optIn',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentTalentPoolController@optIn',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::cNIiYFO77r9KCJbU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::k5xtxjPVXrMy6J10' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/me/talent-pool/opt-out',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentTalentPoolController@optOut',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentTalentPoolController@optOut',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::k5xtxjPVXrMy6J10',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::h4hiJorXmg4BzEBq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/me/talent-pool/inquiries/{inquiry}/respond',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'role:user',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\StudentTalentPoolController@respondToInterview',
        'controller' => 'App\\Http\\Controllers\\Api\\StudentTalentPoolController@respondToInterview',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::h4hiJorXmg4BzEBq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nOJoTvdv2stdQapi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'up',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:830:"function () {
                    $exception = null;

                    try {
                        \\Illuminate\\Support\\Facades\\Event::dispatch(new \\Illuminate\\Foundation\\Events\\DiagnosingHealth);
                    } catch (\\Throwable $e) {
                        if (app()->hasDebugModeEnabled()) {
                            throw $e;
                        }

                        report($e);

                        $exception = $e->getMessage();
                    }

                    return response(\\Illuminate\\Support\\Facades\\View::file(\'D:\\\\Dev\\\\CodeGen_Box\\\\backend\\\\vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Foundation\\\\Configuration\'.\'/../resources/health-up.blade.php\', [
                        \'exception\' => $exception,
                    ]), status: $exception ? 500 : 200);
                }";s:5:"scope";s:54:"Illuminate\\Foundation\\Configuration\\ApplicationBuilder";s:4:"this";N;s:4:"self";s:32:"00000000000004e10000000000000000";}}',
        'as' => 'generated::nOJoTvdv2stdQapi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3W5oHQWkYRNulvx4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:44:"function () {
    return \\view(\'welcome\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000004f50000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::3W5oHQWkYRNulvx4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:85:"function () {
    return \\response()->json([\'message\' => \'Unauthenticated.\'], 401);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000006430000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'storage.local' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'storage/{path}',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:3:{s:4:"disk";s:5:"local";s:6:"config";a:5:{s:6:"driver";s:5:"local";s:4:"root";s:46:"D:\\Dev\\CodeGen_Box\\backend\\storage\\app/private";s:5:"serve";b:1;s:5:"throw";b:0;s:6:"report";b:0;}s:12:"isProduction";b:0;}s:8:"function";s:323:"function (\\Illuminate\\Http\\Request $request, string $path) use ($disk, $config, $isProduction) {
                    return (new \\Illuminate\\Filesystem\\ServeFile(
                        $disk,
                        $config,
                        $isProduction
                    ))($request, $path);
                }";s:5:"scope";s:47:"Illuminate\\Filesystem\\FilesystemServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000006450000000000000000";}}',
        'as' => 'storage.local',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'storage.local.upload' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'storage/{path}',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:3:{s:4:"disk";s:5:"local";s:6:"config";a:5:{s:6:"driver";s:5:"local";s:4:"root";s:46:"D:\\Dev\\CodeGen_Box\\backend\\storage\\app/private";s:5:"serve";b:1;s:5:"throw";b:0;s:6:"report";b:0;}s:12:"isProduction";b:0;}s:8:"function";s:325:"function (\\Illuminate\\Http\\Request $request, string $path) use ($disk, $config, $isProduction) {
                    return (new \\Illuminate\\Filesystem\\ReceiveFile(
                        $disk,
                        $config,
                        $isProduction
                    ))($request, $path);
                }";s:5:"scope";s:47:"Illuminate\\Filesystem\\FilesystemServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000006470000000000000000";}}',
        'as' => 'storage.local.upload',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
