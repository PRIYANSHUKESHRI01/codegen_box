<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0; padding:0; background-color:#F7F8FC; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">
    <?php
        $drive = $mapping->placementDrive;
        $company = $drive->company;
        $eligibility = $mapping->effectiveEligibility();
    ?>
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#F7F8FC; padding:32px 16px;">
        <tr>
            <td align="center">
                <table role="presentation" width="520" cellpadding="0" cellspacing="0" style="background-color:#FFFFFF; border-radius:16px; overflow:hidden; border:1px solid #E5E7EB;">
                    <tr>
                        <td style="padding:28px 32px 0 32px;">
                            <span style="font-size:20px; font-weight:800; color:#111827;">CodeGen</span> <span style="color:#4F46E5;">Box</span>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:20px 32px 0 32px;">
                            <span style="display:inline-block; background-color:#FEF3C7; color:#92400E; font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:0.05em; padding:4px 10px; border-radius:999px; margin-bottom:12px;">
                                Placeholder Template
                            </span>
                            <h1 style="font-size:18px; margin:12px 0 8px 0; color:#111827;">A new placement drive is proposed for <?php echo e($mapping->college->name); ?></h1>
                            <p style="font-size:14px; line-height:1.6; color:#4B5563; margin:0 0 20px 0;">
                                Hi <?php echo e($tpo->name); ?>,
                                <?php if($mapping->proposedByCompany()): ?>
                                    <?php echo e($company->name); ?> has proposed mapping the following placement drive to
                                <?php else: ?>
                                    Mellow has proposed mapping the following placement drive to
                                <?php endif; ?>
                                <?php echo e($mapping->college->name); ?>. Review the details below and approve or decline it from
                                your dashboard — it will not appear for your students until you approve it.
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:0 32px;">
                            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#F7F8FC; border-radius:10px; border:1px solid #E5E7EB;">
                                <tr>
                                    <td style="padding:18px 20px;">
                                        <p style="font-size:16px; font-weight:800; color:#111827; margin:0 0 2px 0;"><?php echo e($company->name); ?></p>
                                        <p style="font-size:13px; color:#4B5563; margin:0 0 14px 0;"><?php echo e($drive->role_title); ?></p>

                                        <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                                            <tr>
                                                <td style="padding:6px 0; font-size:12px; color:#6B7280; width:40%;">CTC Range</td>
                                                <td style="padding:6px 0; font-size:12px; color:#111827; font-weight:700;"><?php echo e($drive->ctc_range ?? 'Not disclosed'); ?></td>
                                            </tr>
                                            <tr>
                                                <td style="padding:6px 0; font-size:12px; color:#6B7280;">Drive Date</td>
                                                <td style="padding:6px 0; font-size:12px; color:#111827; font-weight:700;"><?php echo e($drive->drive_date->timezone('Asia/Kolkata')->format('d M Y, g:i A')); ?></td>
                                            </tr>
                                            <?php if($drive->duration_minutes): ?>
                                            <tr>
                                                <td style="padding:6px 0; font-size:12px; color:#6B7280;">Duration</td>
                                                <td style="padding:6px 0; font-size:12px; color:#111827; font-weight:700;"><?php echo e($drive->duration_minutes); ?> minutes</td>
                                            </tr>
                                            <?php endif; ?>
                                            <tr>
                                                <td style="padding:6px 0; font-size:12px; color:#6B7280;">Min CGPA</td>
                                                <td style="padding:6px 0; font-size:12px; color:#111827; font-weight:700;"><?php echo e($eligibility['min_cgpa'] ?? 'Open'); ?></td>
                                            </tr>
                                            <tr>
                                                <td style="padding:6px 0; font-size:12px; color:#6B7280;">Max Backlogs</td>
                                                <td style="padding:6px 0; font-size:12px; color:#111827; font-weight:700;"><?php echo e($eligibility['max_backlogs'] ?? 'Open'); ?></td>
                                            </tr>
                                            <tr>
                                                <td style="padding:6px 0; font-size:12px; color:#6B7280;">Eligible Branches</td>
                                                <td style="padding:6px 0; font-size:12px; color:#111827; font-weight:700;"><?php echo e(!empty($eligibility['eligible_branches']) ? implode(', ', $eligibility['eligible_branches']) : 'All branches'); ?></td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:24px 32px;">
                            <a href="<?php echo e(config('app.frontend_url')); ?>/admin/drives?tab=pending" style="display:inline-block; background-color:#4F46E5; color:#FFFFFF; text-decoration:none; font-size:14px; font-weight:700; padding:12px 24px; border-radius:10px;">
                                Review &amp; Respond
                            </a>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:0 32px 28px 32px;">
                            <p style="font-size:12px; line-height:1.6; color:#9CA3AF; margin:0;">
                                Sign in to your TPO dashboard to approve or decline this proposal. If you weren't expecting
                                this email, contact Mellow support.
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
<?php /**PATH D:\Dev\Mellow_CodeChef\backend\resources\views/emails/drive-mapping-proposal.blade.php ENDPATH**/ ?>