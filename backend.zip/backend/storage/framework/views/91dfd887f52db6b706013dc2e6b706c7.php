<?php echo $__env->make('emails.partials.header', ['preheader' => ($inquiry->candidate->user->name ?? 'A candidate').' '.($decision === 'decline' ? 'declined' : 'confirmed').' your HR interview invite.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <tr>
                        <td style="padding:20px 32px 0 32px;">
                            <span style="display:inline-block; background-color:<?php echo e($decision === 'decline' ? '#FEE2E2' : '#D1FAE5'); ?>; color:<?php echo e($decision === 'decline' ? '#991B1B' : '#065F46'); ?>; font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:0.05em; padding:4px 10px; border-radius:999px; margin-bottom:12px;">
                                <?php echo e($decision === 'decline' ? 'Declined' : 'Confirmed'); ?>

                            </span>
                            <h1 style="font-size:18px; margin:12px 0 8px 0; color:#111827;">
                                <?php echo e($inquiry->candidate->user->name ?? 'The candidate'); ?> <?php echo e($decision === 'decline' ? 'declined' : 'confirmed'); ?> your HR interview invite
                            </h1>
                            <p style="font-size:14px; line-height:1.6; color:#4B5563; margin:0 0 20px 0;">
                                Hi <?php echo e($recruiter->name); ?>,
                                <?php if($decision === 'decline'): ?>
                                    the candidate has declined the HR interview slot you scheduled through the Talent Pool. You can reach out again or move on to another candidate.
                                <?php else: ?>
                                    the candidate has confirmed they'll attend the HR interview slot you scheduled through the Talent Pool.
                                <?php endif; ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:24px 32px;">
                            <a href="<?php echo e(config('app.frontend_url')); ?>/admin/company/talent-pool" style="display:inline-block; background-color:#4F46E5; color:#FFFFFF; text-decoration:none; font-size:14px; font-weight:700; padding:12px 24px; border-radius:10px;">
                                View on CodeGen Box
                            </a>
                        </td>
                    </tr>
<?php echo $__env->make('emails.partials.footer', ['note' => "You're receiving this because you scheduled this interview through Mellow's Talent Pool."], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH D:\Dev\CodeGen_Box\backend\resources\views/emails/talent-pool-interview-response.blade.php ENDPATH**/ ?>