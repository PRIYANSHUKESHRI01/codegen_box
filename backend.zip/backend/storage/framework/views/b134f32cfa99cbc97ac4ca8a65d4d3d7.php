<?php
    $student = $session->contestParticipant->user;
    $contest = $session->contestParticipant->contest;
    $locked = $session->isLocked();
?>
<?php echo $__env->make('emails.partials.header', ['width' => 560, 'preheader' => 'Proctoring report for '.$student->name.' in '.$contest->title.' — '.$session->violation_count.' strike(s) recorded.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <tr>
                        <td style="padding:20px 32px 0 32px;">
                            <span style="display:inline-block; background-color:<?php echo e($locked ? '#FEE2E2' : '#FEF3C7'); ?>; color:<?php echo e($locked ? '#991B1B' : '#92400E'); ?>; font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:0.05em; padding:4px 10px; border-radius:999px; margin-bottom:12px;">
                                <?php echo e($locked ? 'Locked Out — 3 Strikes' : 'Flagged — Under Threshold'); ?>

                            </span>
                            <h1 style="font-size:18px; margin:12px 0 8px 0; color:#111827;">
                                Proctoring report — <?php echo e($student->name); ?> in <?php echo e($contest->title); ?>

                            </h1>
                            <p style="font-size:14px; line-height:1.6; color:#4B5563; margin:0 0 20px 0;">
                                Hi <?php echo e($recipient->name); ?>, this contest attempt recorded
                                <?php echo e($session->violation_count); ?> strike<?php echo e($session->violation_count === 1 ? '' : 's'); ?>

                                (fullscreen exit, tab switch, or a detected devtools open).
                                <?php if($locked): ?>
                                    The student was automatically locked out of the contest once the 3rd strike was recorded, and whatever code they had open was submitted for judging.
                                <?php else: ?>
                                    They finished the contest without reaching the 3-strike lockout, but at least one violation was recorded and is worth a look.
                                <?php endif; ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:0 32px;">
                            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#F7F8FC; border-radius:10px; border:1px solid #E5E7EB;">
                                <tr>
                                    <td style="padding:18px 20px;">
                                        <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                                            <tr>
                                                <td style="padding:6px 0; font-size:12px; color:#6B7280; width:40%;">Student</td>
                                                <td style="padding:6px 0; font-size:12px; color:#111827; font-weight:700;"><?php echo e($student->name); ?> (<?php echo e($student->email); ?>)</td>
                                            </tr>
                                            <?php if($student->roll_number): ?>
                                            <tr>
                                                <td style="padding:6px 0; font-size:12px; color:#6B7280;">Roll Number</td>
                                                <td style="padding:6px 0; font-size:12px; color:#111827; font-weight:700;"><?php echo e($student->roll_number); ?></td>
                                            </tr>
                                            <?php endif; ?>
                                            <?php if($student->section): ?>
                                            <tr>
                                                <td style="padding:6px 0; font-size:12px; color:#6B7280;">Section</td>
                                                <td style="padding:6px 0; font-size:12px; color:#111827; font-weight:700;"><?php echo e($student->section); ?></td>
                                            </tr>
                                            <?php endif; ?>
                                            <tr>
                                                <td style="padding:6px 0; font-size:12px; color:#6B7280;">Contest</td>
                                                <td style="padding:6px 0; font-size:12px; color:#111827; font-weight:700;"><?php echo e($contest->title); ?></td>
                                            </tr>
                                            <tr>
                                                <td style="padding:6px 0; font-size:12px; color:#6B7280;">Final Status</td>
                                                <td style="padding:6px 0; font-size:12px; color:<?php echo e($locked ? '#991B1B' : '#92400E'); ?>; font-weight:700;"><?php echo e($locked ? 'Locked out' : 'Completed with warnings'); ?></td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:20px 32px 0 32px;">
                            <p style="font-size:12px; font-weight:800; color:#111827; text-transform:uppercase; letter-spacing:0.04em; margin:0 0 10px 0;">Activity Timeline</p>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:0 32px;">
                            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #E5E7EB; border-radius:10px; overflow:hidden;">
                                <tr style="background-color:#F9FAFB;">
                                    <td style="padding:8px 14px; font-size:11px; font-weight:700; color:#6B7280;">Time</td>
                                    <td style="padding:8px 14px; font-size:11px; font-weight:700; color:#6B7280;">Event</td>
                                    <td style="padding:8px 14px; font-size:11px; font-weight:700; color:#6B7280;">Strike?</td>
                                </tr>
                                <?php $__currentLoopData = $session->violations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $violation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="padding:8px 14px; font-size:12px; color:#4B5563; border-top:1px solid #E5E7EB;"><?php echo e($violation->occurred_at->timezone('Asia/Kolkata')->format('g:i:s A')); ?></td>
                                    <td style="padding:8px 14px; font-size:12px; color:#111827; border-top:1px solid #E5E7EB;"><?php echo e(\App\Models\ProctoringViolation::label($violation->type)); ?></td>
                                    <td style="padding:8px 14px; font-size:12px; border-top:1px solid #E5E7EB; color:<?php echo e($violation->counted_toward_lock ? '#991B1B' : '#6B7280'); ?>; font-weight:<?php echo e($violation->counted_toward_lock ? '700' : '400'); ?>;"><?php echo e($violation->counted_toward_lock ? 'Yes' : 'No'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:24px 32px;">
                            <a href="<?php echo e(config('app.frontend_url')); ?>/admin/proctoring" style="display:inline-block; background-color:#4F46E5; color:#FFFFFF; text-decoration:none; font-size:14px; font-weight:700; padding:12px 24px; border-radius:10px;">
                                Review in Dashboard
                            </a>
                        </td>
                    </tr>
<?php echo $__env->make('emails.partials.footer', ['note' => "No video or audio was uploaded for this session — recording happens only in the student's browser and is not stored by the platform. This report reflects the activity log only. If this looks like a false alarm, you can reinstate the student from the dashboard."], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH D:\Dev\CodeGen_Box\backend\resources\views/emails/proctoring-violation-report.blade.php ENDPATH**/ ?>